﻿/**********************************************************************************
 * NOME:            FuncGeral
 * CLASSE:          Representação do objeto de Funções Gerais
 * DT CRIAÇÃO:      27/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Monstro (mFacine)
 * OBSERVAÇÕES:     Metodos utilizados por formulários e Classes
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace VETERINARIO
{
    public class FuncGeral
    {

        /// <SUMMARY>
        /// Vetor de byte utilizados para a criptografia (chave externa)
        /// </SUMMARY>
        private static byte[] bIV = { 0x50, 0x08, 0xF1, 0xDD, 0xDE, 0x3C, 0xF2, 0x18, 0x44, 0x74, 0x19, 0x2C, 0x53, 0x49, 0xAB, 0xBC };

        /// <summary>
        /// Representação de valor em base 64 (chave interna)
        /// O valor represanta a transformação para base64 de 
        /// um conjunto de 32 caracteres (8 * 32 - 256 bits)
        /// a chave é: "Criptografia com Rijndael / AES"
        /// </summary>
        private const string cryptoKey = "Q3JpcHRvZ3JhZmlhcyBjb20gUmluamRhZWwgLyBBRVM=";



        /***********************************************************************
        * NOME:            LimpaTela       
        * METODO:          Limpa cada Componente editável que está no painel 
        *                  Detalhe
        * PARAMETRO:       Nome do Formulário                 
        * DT CRIAÇÃO:      27/05/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine) 
        **********************************************************************/
        public void LimpaTela(Form objForm)
        {
            //(27/05/2019-mfacine) Percorre todos os componentes do Formulário
            foreach (Control pnl in objForm.Controls)
            {
                //(27/05/2019-mfacine) Perguntar se é um painel e se o nome é pnl_Detalhe
                if (pnl is Panel && pnl.Name == "pnl_Detalhe")
                {
                    //(27/05/2019-mfacine) Percorre todos os componentes do pnl_Detalhe
                    foreach (Control ctrl1 in pnl.Controls)
                    {
                        if (ctrl1 is TextBox)
                        {
                            ctrl1.Text = "";
                        }

                        if (ctrl1 is Label && Convert.ToInt16(ctrl1.Tag) == 1)
                        {
                            ctrl1.Text = "";
                        }

                        if (ctrl1 is ListView)
                        {
                            ListView Ctrl = (ListView)ctrl1;
                            Ctrl.Clear();
                        }

                    }
                }
            }
        }

        /***********************************************************************
        * NOME:            HabilitaTela       
        * METODO:          Habilita cada Componente editável que está no painel 
        *                  Detalhe
        * PARAMETRO:       Nome do Formulário, Variável Booleana                 
        * DT CRIAÇÃO:      27/05/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine) 
        **********************************************************************/
        public void HabilitaTela(Form objForm, bool hab)
        {
            //(27/05/2019-Jose Egito) Percorre todos os componentes do Formulario
            foreach (Control pnl in objForm.Controls)
            {
                //(27/05/2019-Jose Egito) Perguntar se é um painel e se o nome é pnl_Detalhe
                if (pnl is Panel && pnl.Name == "pnl_Detalhe")
                {
                    //(27/05/2019-Jose Egito) Percorre todos os componentes do pnl_Detalhe
                    foreach (Control ctrl1 in pnl.Controls)
                    {
                        if (ctrl1 is TextBox && Convert.ToInt16(ctrl1.Tag) != 1)
                        {
                            ctrl1.Enabled = hab;
                        }
                    }
                }
            }
        }

        /***********************************************************************
        * NOME:            StatusBtn       
        * METODO:          Definir o Status dos botões da tela no pnl_Button
        * PARAMETRO:       Nome do Formulário, status (int)                 
        * DT CRIAÇÃO:      27/05/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine) 
        **********************************************************************/
        public void StatusBtn(Form objForm, int iStatus)
        {
            //(27/05/2019-mfacine) Percorre todos os componentes do Formulário
            foreach (Control pnl in objForm.Controls)
            {
                //(27/05/2019-mfacine) Perguntar se é um painel e se o nome é pnl_Button
                if (pnl is Panel && pnl.Name == "pnl_Button")
                {
                    //(27/05/2019-mfacine) Percorre todos os componentes do pnl_Button
                    foreach (Control ctrl1 in pnl.Controls)
                    {
                        switch (iStatus)
                        {
                            case 0:
                                {
                                    //(27/05/2019-mfacine) Perguntar se é o btn novo
                                    if (ctrl1.Name == "btn_Novo")
                                    {
                                        ctrl1.Enabled = true;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Alterar
                                    if (ctrl1.Name == "btn_Alterar")
                                    {
                                        ctrl1.Enabled = false;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Excluir
                                    if (ctrl1.Name == "btn_Excluir")
                                    {
                                        ctrl1.Enabled = false;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Confirmar
                                    if (ctrl1.Name == "btn_Confirmar")
                                    {
                                        ctrl1.Enabled = false;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Cancelar
                                    if (ctrl1.Name == "btn_Cancelar")
                                    {
                                        ctrl1.Enabled = false;
                                    }
                                    break;
                                }

                            case 1:
                                {
                                    //(27/05/2019-mfacine) Perguntar se é o btn novo
                                    if (ctrl1.Name == "btn_Novo")
                                    {
                                        ctrl1.Enabled = true;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Alterar
                                    if (ctrl1.Name == "btn_Alterar")
                                    {
                                        ctrl1.Enabled = true;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Excluir
                                    if (ctrl1.Name == "btn_Excluir")
                                    {
                                        ctrl1.Enabled = true;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Confirmar
                                    if (ctrl1.Name == "btn_Confirmar")
                                    {
                                        ctrl1.Enabled = false;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Cancelar
                                    if (ctrl1.Name == "btn_Cancelar")
                                    {
                                        ctrl1.Enabled = false;
                                    }
                                    break;
                                }
                            case 2:
                                {
                                    //(27/05/2019-mfacine) Perguntar se é o btn novo
                                    if (ctrl1.Name == "btn_Novo")
                                    {
                                        ctrl1.Enabled = false;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Alterar
                                    if (ctrl1.Name == "btn_Alterar")
                                    {
                                        ctrl1.Enabled = false;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Excluir
                                    if (ctrl1.Name == "btn_Excluir")
                                    {
                                        ctrl1.Enabled = false;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Confirmar
                                    if (ctrl1.Name == "btn_Confirmar")
                                    {
                                        ctrl1.Enabled = true;
                                    }

                                    //(27/05/2019-mfacine) Perguntar se é o btn Cancelar
                                    if (ctrl1.Name == "btn_Cancelar")
                                    {
                                        ctrl1.Enabled = true;
                                    }
                                    break;
                                }

                        }


                    }
                }
            }
        }

        /***********************************************************************
        * NOME:            Criptografa        
        * METODO:          Criptografa o Password do usuário e retorna o 
        *                   Password criptografado
        * PARAMETRO:       String sPassWord
        * DT CRIAÇÃO:      27/05/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine) 
        ***********************************************************************/
        public string Criptografa(string sPassWord)
        {

            try
            {
                //(27/05/2019-mfacine) Se a string não está vazia, executa a criptografia
                if (!string.IsNullOrEmpty(sPassWord))
                {
                    //(27/05/2019-mfacine) Cria instancias de vetores de bytes com as chaves                
                    byte[] bKey = Convert.FromBase64String(cryptoKey);
                    byte[] bText = new UTF8Encoding().GetBytes(sPassWord);

                    //(27/05/2019-mfacine) Instancia a classe de criptografia Rijndael
                    Rijndael rijndael = new RijndaelManaged();

                    //(27 / 05 / 2019 - mfacine)
                    // Define o tamanho da chave "256 = 8 * 32"                
                    // Lembre-se: chaves possíves:                
                    // 128 (16 caracteres), 192 (24 caracteres) e 256 (32 caracteres)                
                    rijndael.KeySize = 256;

                    //(27 / 05 / 2019 - mfacine)
                    // Cria o espaço de memória para guardar o valor criptografado:                
                    MemoryStream mStream = new MemoryStream();
                    // Instancia o encriptador                 
                    CryptoStream encryptor = new CryptoStream(
                        mStream,
                        rijndael.CreateEncryptor(bKey, bIV),
                        CryptoStreamMode.Write);

                    //(27/05/2019-mfacine)
                    // Faz a escrita dos dados criptografados no espaço de memória
                    encryptor.Write(bText, 0, bText.Length);
                    // Despeja toda a memória.                
                    encryptor.FlushFinalBlock();
                    // Pega o vetor de bytes da memória e gera a string criptografada                
                    return Convert.ToBase64String(mStream.ToArray());
                }
                else
                {
                    //(27/05/2019-mfacine) Se a string for vazia retorna nulo                
                    return null;
                }
            }
            catch (Exception ex)
            {
                //(27/05/2019-mfacine) Se algum erro ocorrer, dispara a exceção            
                throw new ApplicationException("Erro ao criptografar", ex);
            }
        }



        /*****************************************************************************
        * Nome           : DesCriptografa
        * Procedimento   : Descriptografa o password do usuário e retorna o 
        *                  pass descriptografado
        * Parametros     : sCriptoPassWord
        * Data  Criação  : 27/05/2018
        * Data Alteração : -
        * Escrito por    : mfacine
        * ***************************************************************************/
        public string DesCriptografa(string sCriptoPassWord)
        {
            try
            {
                //(27/05/2019-mfacine) Se a string não está vazia, executa a criptografia           
                if (!string.IsNullOrEmpty(sCriptoPassWord))
                {
                    //(27/05/2019-mfacine) Cria instancias de vetores de bytes com as chaves                
                    byte[] bKey = Convert.FromBase64String(cryptoKey);
                    byte[] bText = Convert.FromBase64String(sCriptoPassWord);

                    // Instancia a classe de criptografia Rijndael                
                    Rijndael rijndael = new RijndaelManaged();

                    //(27/05/2019-mfacine)
                    // Define o tamanho da chave "256 = 8 * 32"                
                    // Lembre-se: chaves possíves:                
                    // 128 (16 caracteres), 192 (24 caracteres) e 256 (32 caracteres)                
                    rijndael.KeySize = 256;

                    //(27/05/2019-mfacine) Cria o espaço de memória para guardar o valor DEScriptografado:               
                    MemoryStream mStream = new MemoryStream();

                    //(27/05/2019-mfacine) Instancia o Decriptador                 
                    CryptoStream decryptor = new CryptoStream(
                        mStream,
                        rijndael.CreateDecryptor(bKey, bIV),
                        CryptoStreamMode.Write);

                    //(27/05/2019-mfacine)
                    // Faz a escrita dos dados criptografados no espaço de memória   
                    decryptor.Write(bText, 0, bText.Length);
                    // Despeja toda a memória.                
                    decryptor.FlushFinalBlock();
                    // Instancia a classe de codificação para que a string venha de forma correta         
                    UTF8Encoding utf8 = new UTF8Encoding();
                    // Com o vetor de bytes da memória, gera a string descritografada em UTF8       
                    return utf8.GetString(mStream.ToArray());
                }
                else
                {
                    //(27/05/2019-mfacine) Se a string for vazia retorna nulo                
                    return null;
                }
            }
            catch (Exception ex)
            {
                //(27/05/2019-mfacine) Se algum erro ocorrer, dispara a exceção            
                throw new ApplicationException("Erro ao descriptografar", ex);
            }
        }

    }
}