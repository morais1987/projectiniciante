﻿/**********************************************************************************
 * NOME:            Connection
 * CLASSE:          Representação da classe de conexão
 * DT CRIAÇÃO:      07/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Monstro (mFacine)
 * OBSERVAÇÕES:     Classe que faz a conexão com o banco de dados
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO
{
    public class Connection
    {
        //Metodo da classe que retorna o caminho da conexão
        public static string ConnectionPath()
        {
            return @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDBFilename=C:\Users\JoseEgitos\Documents\Visual Studio 2015\Projects\VETERINARIO\VETERINARIO\VETERINARIO\BANCODEDADOS.MDF;Integrated Security=True; Connect Timeout = 30";
        }
    }
}
