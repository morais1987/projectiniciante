﻿/**********************************************************************************
 * NOME:            BDConsulta
 * CLASSE:          Representação da classe de banco de dados Consulta
 * DT CRIAÇÃO:      13/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Guilherme / Jose Henrique
 * OBSERVAÇÕES:     
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace VETERINARIO
{
    public class BDConsulta
    {

        //Destructor da Classe
        ~BDConsulta()
        {
        }

        /***********************************************************************
        * NOME          :  Incluir          
        * METODO        :  Responsável por incluir o registro na tabela.
        *                  Inclui um registro na tabela PET_CONSULTA         
        * DT CRIAÇÃO    :  07/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public int Incluir(Consulta aobjVonsulta)
        {



            //(07/05/2019-mfacine) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "INSERT INTO PET_CONSULTA" +
                            "(" +
                            "ICOD_CONSULTA , " +
                            "ICOD_VETERINARIO  , " +
                            "ICOD_CLIENTE," +
                            "ICOD_PET ," +
                            "HR_CONSULTA ," +
                            "DDT_CONSULTA ," +
                            ")" +
                            "VALUES " +
                            "(" +
                            "@ICOD_CONSULTA, " +
                            "@ICOD_VETERINARIO  , " +
                            "@ICOD_CLIENTE ," +
                            "@ICOD_PET ," +
                            "@HR_CONSULTA ," +
                            "@DDT_CONSULTA ," +
                            ");" +
                            "SELECT IDENT_CURRENT('PET_CONSULTA') as 'id'";

            //ToDo: Continuar Daqui.

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@ICOD_CONSULTA", aobjVonsulta.COD_CONSULTA);
            objCmd.Parameters.AddWithValue("@ICOD_VETERINARIOL", aobjVonsulta.COD_VETERINARIO);
            objCmd.Parameters.AddWithValue("@ICOD_CLIENTE", aobjVonsulta.COD_CLIENTE);
            objCmd.Parameters.AddWithValue("@ICOD_PET", aobjVonsulta.COD_PET);
            objCmd.Parameters.AddWithValue("@HR_CONSULTA", aobjVonsulta.HR_CONSULTA);
            objCmd.Parameters.AddWithValue("@DDT_CONSULTA", aobjVonsulta.DT_CONSULTA);


            try
            {
                //(12.06.2019-Guilherme/Jose) Abro a Conexão com o BD
                objCon.Open();

                //(12.06.2019-Guilherme/Jose) Executo o comando de forma escalar
                int _id = Convert.ToInt16(objCmd.ExecuteScalar());

                //(12.06.2019-Guilherme/Jose) Fecho a Conexão com o BD
                objCon.Close();

                return _id;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }


        /***********************************************************************
        * NOME          :  Alterar          
        * METODO        :  Responsável por alterar o registro na tabela.
        *                  Alterar um registro na tabela PET_CONSULTA         
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Boolean Alterar(Consulta aobjVonsulta)
        {
            if (aobjVonsulta.COD_PET != -1)
            {

                SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

                string varsql = "UPDATE PET_CONSULTA SET " +
                    "ICOD_ANIMAL   = @ICOD_ANIMAL   , " +
                    "ICOD_RACA  = @ICOD_RACA  , " +
                    "ICOD_CLIENTE   = @ICOD_CLIENTE   , " +
                    "SGEN_ANIMAL  = @SGEN_ANIMAL  , " +
                    "SNM_PET   = @SNM_PET   , " +
                    "IPS_PET  = @IPS_PET  , " +
                    "IID_PET  = @IID_PET  , " +
                    " WHERE ICOD_PET = @ICOD_PET ";

                SqlCommand objCmd = new SqlCommand(varsql, objCon);
                objCmd.Parameters.AddWithValue("@ICOD_CONSULTA", aobjVonsulta.COD_CONSULTA);
                objCmd.Parameters.AddWithValue("@ICOD_VETERINARIOL", aobjVonsulta.COD_VETERINARIO);
                objCmd.Parameters.AddWithValue("@ICOD_CLIENTE", aobjVonsulta.COD_CLIENTE);
                objCmd.Parameters.AddWithValue("@ICOD_PET", aobjVonsulta.COD_PET);
                objCmd.Parameters.AddWithValue("@HR_CONSULTA", aobjVonsulta.HR_CONSULTA);
                objCmd.Parameters.AddWithValue("@DDT_CONSULTA", aobjVonsulta.DT_CONSULTA);

                try
                {
                    objCon.Open();
                    objCmd.ExecuteNonQuery();
                    objCon.Close();
                    return true;
                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  Excluir          
        * METODO        :  Responsável por deletar o registro na tabela PET_CONSULTA          
        * DT CRIAÇÃO    :  13/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Boolean Excluir(Consulta aobjVonsulta)
        {

            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varsql = "DELETE FROM PET_CONSULTA " +
                            " WHERE ICOD_PET = @ICOD_PET ";
            SqlCommand objCmd = new SqlCommand(varsql, objCon);

            objCmd.Parameters.AddWithValue("@ICOD_PET", aobjVonsulta.COD_PET);

            try
            {
                objCon.Open();
                objCmd.ExecuteNonQuery();
                objCon.Close();
                return true;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO NA EXCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  FindByVETERINARIO          
        * METODO        :  Responsável por encontrar o registro na tabela.
        *                  Encontra um registro na tabela PET_CONSULTA          
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Consulta FindByVETERINARIO(Consulta aobjVonsulta)
        {
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "SELECT * FROM PET_CONSULTA " +
                            "WHERE ICOD_PET = @ICOD_PET";

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@ICOD_PET", aobjVonsulta.COD_PET);

            objCon.Open();

            SqlDataReader objDtr = objCmd.ExecuteReader();

            if (objDtr.HasRows)
            {
                objDtr.Read();

                
                aobjVonsulta.COD_VETERINARIO = Convert.ToInt16(objDtr["ICOD_VETERINARIO"]);
                aobjVonsulta.COD_CLIENTE = Convert.ToInt16(objDtr["ICOD_CLIENTE"]);
                aobjVonsulta.COD_PET = Convert.ToInt16(objDtr["ICOD_PET"]);
                aobjVonsulta.HR_CONSULTA = Convert.ToDateTime(objDtr["HR_CONSULTA"]);
                aobjVonsulta.DT_CONSULTA = Convert.ToDateTime(objDtr["DDT_CONSULTA"]);
                


                objCon.Close();
                objDtr.Close();
                return aobjVonsulta;
            }

            else
            {
                objCon.Close();
                objDtr.Close();
                return null;
            }
        }

        /***********************************************************************
        * NOME          :  FindByPET       
        * METODO        :  Responsável por encontrar o registro na tabela.
        *                  Encontra um registro na tabela PET_CONSULTA          
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Consulta FindByNMConsulta(Consulta aobjVonsulta)
        {
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "SELECT * FROM PET_CONSULTA " +
                            "WHERE ICOD_PET = @ICOD_PET";

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@ICOD_PET", aobjVonsulta.COD_PET);

            objCon.Open();

            SqlDataReader objDtr = objCmd.ExecuteReader();

            if (objDtr.HasRows)
            {
                objDtr.Read();

                aobjVonsulta.COD_VETERINARIO = Convert.ToInt16(objDtr["ICOD_VETERINARIO"]);
                aobjVonsulta.COD_CLIENTE = Convert.ToInt16(objDtr["ICOD_CLIENTE"]);
                aobjVonsulta.COD_PET = Convert.ToInt16(objDtr["ICOD_PET"]);
                aobjVonsulta.HR_CONSULTA = Convert.ToDateTime(objDtr["HR_CONSULTA"]);
                aobjVonsulta.DT_CONSULTA = Convert.ToDateTime(objDtr["DDT_CONSULTA"]);



                objCon.Close();
                objDtr.Close();
                return aobjVonsulta;
            }

            else
            {
                objCon.Close();
                objDtr.Close();
                return null;
            }
        }



        /***********************************************************************
        * NOME          :  FindAllUSUARIO  
        * METODO        :  Responsável por encontrar todos os Objetos na Base 
        *                  de Dados. Busca todos os registros na tabela PET_CONSULTA.         
        * DT CRIAÇÃO    :  13/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public List<Consulta> FindAllConsulta()
        {
            //(13.05.2019-mfacine) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            //(13.05.2019-mfacine) Cria a variável que conterá o comando SQL
            string varSql = "SELECT * FROM PET_CONSULTA";

            //(13.05.2019-mfacine) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);

            //(13.05.2019-mfacine) Abre a conexão com o banco de dados
            objCon.Open();

            //(13.05.2019-mfacine) Executa o comando para excluir o registro
            SqlDataReader objDtr = objCmd.ExecuteReader();

            List<Consulta> lista = new List<Consulta>();

            if (objDtr.HasRows)
            {
                //(12.06.2019-Guilherme/Jose) Enquanto tiver linha faça
                while (objDtr.Read())
                {
                    //(12.06.2019-Guilherme/Jose) Instância do objto Receita
                    Consulta aobjVonsulta = new Consulta();

                    //(12.06.2019-Guilherme/Jose) Coloca os dados do Reader no Objeto
                    aobjVonsulta.COD_VETERINARIO = Convert.ToInt16(objDtr["ICOD_VETERINARIO"]);
                    aobjVonsulta.COD_CLIENTE = Convert.ToInt16(objDtr["ICOD_CLIENTE"]);
                    aobjVonsulta.COD_PET = Convert.ToInt16(objDtr["ICOD_PET"]);
                    aobjVonsulta.HR_CONSULTA = Convert.ToDateTime(objDtr["HR_CONSULTA"]);
                    aobjVonsulta.DT_CONSULTA = Convert.ToDateTime(objDtr["DDT_CONSULTA"]);



                    lista.Add(aobjVonsulta);
                }
                //(12.06.2019-Guilherme/Jose) Fecha a conexão com o banco de dados
                objCon.Close();

                //(12.06.2019-Guilherme/Jose) Fecha o objeto Reader
                objDtr.Close();

                return lista;
            }
            else
            {
                //(12.06.2019-Guilherme/Jose) Fecha a conexão com o banco de dados
                objCon.Close();

                //(12.06.2019-Guilherme/Jose) Fecha o objeto Reader
                objDtr.Close();

                return null;
            }

        }

    }
}
