﻿/**********************************************************************************
 * NOME:            Animal
 * CLASSE:          Representação da entidade Animal 
 * DT CRIAÇÃO:      06/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Guilherme / Jose Henrique
 * OBSERVAÇÕES:     Atributos privados com métodos Get e Set públicos
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO
{
    public class Consulta
    {
        //(Guilherme / Jose Henrique  - 06/05/2019) Metodo de Destruição da Classe
        ~Consulta()
        {
        }

        //(Guilherme / Jose Henrique  - 06/05/2019) Atributos/Propriedades Privadas Encapsuladas
        private int vcod_Consulta = -1;
        private int vcod_Veterinario = -1;
        private int vcod_Cliente = -1;
        private int vcod_Pet = -1;
        private DateTime vhr_Consulta = DateTime.MinValue;
        private DateTime vdt_Consulta = DateTime.MinValue;




        //( - 06/05/2019) Metodos/Ações Publicas

        /***********************************************************************
         * NOME:            COD_CONSULTA   
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int COD_CONSULTA
        {
            get { return vcod_Consulta; }
            set { vcod_Consulta = value; }
        }

        /***********************************************************************
        * NOME:              COD_VETERINARIO
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public int COD_VETERINARIO
        {
            get { return vcod_Veterinario; }
            set { vcod_Veterinario = value; }
        }

        /***********************************************************************
         * NOME:                
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int COD_CLIENTE
        {
            get { return vcod_Cliente; }
            set { vcod_Cliente = value; }
        }



        /***********************************************************************
         * NOME:            COD_PET    
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int COD_PET
        {
            get { return vcod_Pet; }
            set { vcod_Pet = value; }
        }

        /***********************************************************************
       * NOME:            HR_COLSULTA
       * METODO:          Representação do atributo Nome com os métodos 
       *                  Get e Set          
       * DT CRIAÇÃO:      11/06/2019    
       * DT ALTERAÇÃO:    -
       * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public DateTime HR_CONSULTA
        {
            get { return vhr_Consulta; }
            set { vhr_Consulta = value; }
        }


        /***********************************************************************
         * NOME:            DT_CONSULTA    
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public DateTime DT_CONSULTA
        {
            get { return vdt_Consulta; }
            set { vdt_Consulta = value; }
        }



      }
   }
        
    


