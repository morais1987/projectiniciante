﻿/**********************************************************************************
 * NOME:            Animal
 * CLASSE:          Representação da entidade Animal 
 * DT CRIAÇÃO:      06/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Guilherme / Jose Henrique
 * OBSERVAÇÕES:     Atributos privados com métodos Get e Set públicos
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO
{
    public class Animal
    {
        //(Guilherme / Jose Henrique - 06/05/2019) Metodo de Destruição da Classe
        ~Animal()
        {
        }

        //(Guilherme / Jose Henrique - 06/05/2019) Atributos/Propriedades Privadas Encapsuladas
        private int vcod_Animal = -1;
        private string vdesc_Animal = null;

        //(Guilherme / Jose Henrique - 06/05/2019) Metodos/Ações Publicas

        /***********************************************************************
         * NOME:                   
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int COD_ANIMAL
        {
            get { return vcod_Animal; }
            set { vcod_Animal = value; }
        }

        /***********************************************************************
        * NOME:               DESC_ANIMAL    
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public string DESC_ANIMAL
        {
            get { return vdesc_Animal; }
            set { vdesc_Animal = value; } 
        }
    }
}
