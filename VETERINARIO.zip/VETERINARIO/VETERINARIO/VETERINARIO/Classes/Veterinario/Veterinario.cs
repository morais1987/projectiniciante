﻿/**********************************************************************************
 * NOME:            Animal
 * CLASSE:          Representação da entidade Animal 
 * DT CRIAÇÃO:      06/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Guilherme / Jose Henrique
 * OBSERVAÇÕES:     Atributos privados com métodos Get e Set públicos
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO
{
    public class Veterinario
    {
        //(mfacine - 06/05/2019) Metodo de Destruição da Classe
        ~Veterinario()
        {
        }

        //(mfacine - 06/05/2019) Atributos/Propriedades Privadas Encapsuladas
        private int vcod_Veterinario = -1;
        private string vnm_Veterinario = null;
        private string vfn_Veterinario = null;


        //(mfacine - 06/05/2019) Metodos/Ações Publicas

        /***********************************************************************
         * NOME:            COD_VETERINARIO     
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int COD_VETERINARIO
        {
            get { return vcod_Veterinario; }
            set { vcod_Veterinario = value; }
        }

        /***********************************************************************
        * NOME:            NM_VETERINARIO    
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public string NM_VETERINARIO
        {
            get { return vnm_Veterinario; }
            set { vnm_Veterinario = value; }
        }


         /***********************************************************************
         * NOME:            FN_VETERIANRIO    
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public string FN_VETERINARIO
        {
            get { return vfn_Veterinario; }
            set { vfn_Veterinario = value; }
        }
    }
    }

