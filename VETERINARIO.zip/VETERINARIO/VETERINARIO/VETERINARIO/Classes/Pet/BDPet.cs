﻿/**********************************************************************************
 * NOME:            BDPet
 * CLASSE:          Representação da classe de banco de dados Pet
 * DT CRIAÇÃO:      13/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Monstro (mFacine)
 * OBSERVAÇÕES:     
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace VETERINARIO
{
    public class BDPet
    {
        //Destructor da Classe
        ~BDPet()
        {
        }

        /***********************************************************************
        * NOME          :  Incluir          
        * METODO        :  Responsável por incluir o registro na tabela.
        *                  Inclui um registro na tabela TB_Pet         
        * DT CRIAÇÃO    :  07/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public int Incluir(Pet aobjPet)
        {
            //ToDo: Rever o pq de não aceitar o objeto da classe
            //Connection objConnection = new Connection();

            //(07/05/2019-mfacine) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "INSERT INTO TB_PET" +
                            "(" +
                            "ICOD_ANIMAL  , " +
                            "ICOD_RACA    , " +
                            "ICOD_CLIENTE , " +
                            "SGEN_PET   , " +
                            "SNM_PET    , " +
                            "IPS_PET    , " +
                            "IID_PET      " +
                            ")" +
                            "VALUES " +
                            "(" +
                            "@ICOD_ANIMAL  , " +
                            "@ICOD_RACA    , " +
                            "@ICOD_CLIENTE , " +
                            "@SGEN_PET   , " +
                            "@SNM_PET    , " +
                            "@IPS_PET    , " +
                            "@IID_PET     " +

                            ");" +
                            "SELECT IDENT_CURRENT('TB_PET') as 'id'";

            //ToDo: Continuar Daqui.

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@ICOD_ANIMAL", aobjPet.COD_ANIMAL);
            objCmd.Parameters.AddWithValue("@ICOD_RACA", aobjPet.COD_RACA);
            objCmd.Parameters.AddWithValue("@ICOD_CLIENTE", aobjPet.COD_CLIENTE);
            objCmd.Parameters.AddWithValue("@SGEN_PET", aobjPet.GEN_PET);
            objCmd.Parameters.AddWithValue("@SNM_PET", aobjPet.NM_PET);
            objCmd.Parameters.AddWithValue("@IPS_PET", aobjPet.PS_PET);
            objCmd.Parameters.AddWithValue("@IID_PET", aobjPet.ID_PET);

            try
            {
                //(20.03.2019-mfacine) Abro a Conexão com o BD
                objCon.Open();

                //(20.03.2019-mfacine) Executo o comando de forma escalar
                int _id = Convert.ToInt16(objCmd.ExecuteScalar());

                //(20.03.2019-mfacine) Fecho a Conexão com o BD
                objCon.Close();

                return _id;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }


        /***********************************************************************
        * NOME          :  Alterar          
        * METODO        :  Responsável por alterar o registro na tabela.
        *                  Alterar um registro na tabela TB_Pet         
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Boolean Alterar(Pet aobjPet)
        {
            if (aobjPet.COD_PET != -1)
            {

                SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

                string varsql = "UPDATE TB_PET SET " +
                    "ICOD_ANIMAL    = @ICOD_ANIMAL,   " +
                    "ICOD_RACA      = @ICOD_RACA,     " +
                    "ICOD_CLIENTE   = @ICOD_CLIENTE,  " +
                    "SGEN_PET     = @SGEN_PET,   " +
                    "SNM_PET      = @SNM_PET,    " +
                    "IPS_PET      = @IPS_PET,    " +
                    "IID_PET      = @IID_PET" +
                    " WHERE ICOD_PET = @ICOD_PET ";

                SqlCommand objCmd = new SqlCommand(varsql, objCon);
                objCmd.Parameters.AddWithValue("@ICOD_PET", aobjPet.COD_PET);
                objCmd.Parameters.AddWithValue("@ICOD_ANIMAL", aobjPet.COD_ANIMAL);
                objCmd.Parameters.AddWithValue("@ICOD_RACA", aobjPet.COD_RACA);
                objCmd.Parameters.AddWithValue("@ICOD_CLIENTE", aobjPet.COD_CLIENTE);
                objCmd.Parameters.AddWithValue("@SGEN_PET", aobjPet.GEN_PET);
                objCmd.Parameters.AddWithValue("@SNM_PET", aobjPet.NM_PET);
                objCmd.Parameters.AddWithValue("@IPS_PET", aobjPet.PS_PET);
                objCmd.Parameters.AddWithValue("@IID_PET", aobjPet.ID_PET);

                try
                {
                    objCon.Open();
                    objCmd.ExecuteNonQuery();
                    objCon.Close();
                    return true;
                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  Excluir          
        * METODO        :  Responsável por deletar o registro na tabela TB_Pet          
        * DT CRIAÇÃO    :  13/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Boolean Excluir(Pet aobjPet)
        {

            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varsql = "DELETE FROM TB_PET " +
                            " WHERE ICOD_PET = @ICOD_PET ";
            SqlCommand objCmd = new SqlCommand(varsql, objCon);

            objCmd.Parameters.AddWithValue("@ICOD_PET", aobjPet.COD_PET);

            try
            {
                objCon.Open();
                objCmd.ExecuteNonQuery();
                objCon.Close();
                return true;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO NA EXCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  FindByPet          
        * METODO        :  Responsável por encontrar o registro na tabela.
        *                  Encontra um registro na tabela TB_Pet          
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Pet FindByPet(Pet aobjPet)
        {
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "SELECT * FROM TB_PET " +
                            "WHERE ICOD_PET = @ICOD_PET";

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@ICOD_PET", aobjPet.COD_PET);

            objCon.Open();

            SqlDataReader objDtr = objCmd.ExecuteReader();

            if (objDtr.HasRows)
            {
                objDtr.Read();

                aobjPet.COD_PET = Convert.ToInt16(objDtr["ICOD_PET"]);
                aobjPet.COD_ANIMAL = Convert.ToInt16(objDtr["ICOD_ANIMAL"]);
                aobjPet.COD_RACA = Convert.ToInt16(objDtr["ICOD_RACA"]);
                aobjPet.COD_CLIENTE = Convert.ToInt16(objDtr["ICOD_CLIENTE"]);
                aobjPet.GEN_PET = objDtr["SGEN_PET"].ToString();
                aobjPet.NM_PET = objDtr["SNM_PET"].ToString();
                aobjPet.PS_PET = Convert.ToInt16(objDtr["IPS_PET"]);
                aobjPet.ID_PET = Convert.ToInt16(objDtr["IID_PET"]);

                objCon.Close();
                objDtr.Close();
                return aobjPet;
            }

            else
            {
                objCon.Close();
                objDtr.Close();
                return null;
            }
        }

        /***********************************************************************
        * NOME          :  FindAllPet  
        * METODO        :  Responsável por encontrar todos os Objetos na Base 
        *                  de Dados. Busca todos os registros na tabela TB_Pet.         
        * DT CRIAÇÃO    :  13/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public List<Pet> FindAllPet()
        {
            //(13.05.2019-mfacine) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            //(13.05.2019-mfacine) Cria a variável que conterá o comando SQL
            string varSql = "SELECT * FROM TB_PET";

            //(13.05.2019-mfacine) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);

            //(13.05.2019-mfacine) Abre a conexão com o banco de dados
            objCon.Open();

            //(13.05.2019-mfacine) Executa o comando para excluir o registro
            SqlDataReader objDtr = objCmd.ExecuteReader();

            List<Pet> lista = new List<Pet>();

            if (objDtr.HasRows)
            {
                //(20.03.2019-mfacine) Enquanto tiver linha faça
                while (objDtr.Read())
                {
                    //(20.03.2019-mfacine) Instância do objto Receita
                    Pet aobjPet = new Pet();

                    //(20.03.2019-mfacine) Coloca os dados do Reader no Objeto
                    aobjPet.COD_PET = Convert.ToInt16(objDtr["ICOD_PET"]);
                    aobjPet.COD_ANIMAL = Convert.ToInt16(objDtr["ICOD_ANIMAL"]);
                    aobjPet.COD_RACA = Convert.ToInt16(objDtr["ICOD_RACA"]);
                    aobjPet.COD_CLIENTE = Convert.ToInt16(objDtr["ICOD_CLIENTE"]);
                    aobjPet.GEN_PET = objDtr["SGEN_PET"].ToString();
                    aobjPet.NM_PET = objDtr["SNM_PET"].ToString();
                    aobjPet.PS_PET = Convert.ToInt16(objDtr["IPS_PET"]);
                    aobjPet.ID_PET = Convert.ToInt16(objDtr["IID_PET"]);

                    lista.Add(aobjPet);
                }
                //(20.03.2019-mfacine) Fecha a conexão com o banco de dados
                objCon.Close();

                //(20.03.2019-mfacine) Fecha o objeto Reader
                objDtr.Close();

                return lista;
            }
            else
            {
                //(20.03.2019-mfacine) Fecha a conexão com o banco de dados
                objCon.Close();

                //(20.03.2019-mfacine) Fecha o objeto Reader
                objDtr.Close();

                return null;
            }

        }

    }
}
