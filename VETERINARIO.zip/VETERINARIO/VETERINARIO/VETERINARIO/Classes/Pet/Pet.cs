﻿/**********************************************************************************
 * NOME:            Animal
 * CLASSE:          Representação da entidade Animal 
 * DT CRIAÇÃO:      06/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Guilherme / Jose Henrique
 * OBSERVAÇÕES:     Atributos privados com métodos Get e Set públicos
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO
{
    public class Pet
    {
        //(Guilherme / Jose Henrique  - 06/05/2019) Metodo de Destruição da Classe
        ~Pet()
        {
        }

        //(Guilherme / Jose Henrique  - 06/05/2019) Atributos/Propriedades Privadas Encapsuladas
        private int vcod_Pet = -1;
        private int vcod_Animal = -1;
        private int vcod_Raca = -1;
        private int vcod_Cliente = -1;
        private string vgen_Pet = null;
        private string vnm_Pet = null;
        private int vps_Pet = -1;
        private int vid_Pet = -1;

        //( - 06/05/2019) Metodos/Ações Publicas

        /***********************************************************************
         * NOME:            COD_PET    
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int COD_PET
        {
            get { return vcod_Pet; }
            set { vcod_Pet = value; }
        }

        /***********************************************************************
        * NOME:              COD_ANIMAL
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public int COD_ANIMAL
        {
            get { return vcod_Animal; }
            set { vcod_Animal = value; }
        }

        /***********************************************************************
         * NOME:            COD_RACA   
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int COD_RACA
        {
            get { return vcod_Raca; }
            set { vcod_Raca = value; }
        }



        /***********************************************************************
         * NOME:            COD_CLIENTE  
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int COD_CLIENTE
        {
            get { return vcod_Cliente; }
            set { vcod_Cliente = value; }
        }

        /***********************************************************************
       * NOME:            GEN_ANIMAL
       * METODO:          Representação do atributo Nome com os métodos 
       *                  Get e Set          
       * DT CRIAÇÃO:      11/06/2019    
       * DT ALTERAÇÃO:    -
       * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public string GEN_PET
        {
            get { return vgen_Pet; }
            set { vgen_Pet = value; }
        }


        /***********************************************************************
         * NOME:            NM_PET    
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public string NM_PET
        {
            get { return vnm_Pet; }
            set { vnm_Pet = value; }
        }

        /***********************************************************************
        * NOME:              MAIL_CLIENTE
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public int PS_PET
        {
            get { return vps_Pet; }
            set { vps_Pet = value; }
        }


        /***********************************************************************
         * NOME:            ID_PET  
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int ID_PET
        {
            get { return vid_Pet; }
            set { vid_Pet = value; }
        }

    }
}

