﻿/**********************************************************************************
 * NOME:            BDGenero
 * CLASSE:          Representação da classe de banco de dados Genero
 * DT CRIAÇÃO:      13/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Monstro (mFacine)
 * OBSERVAÇÕES:     
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace VETERINARIO
{
    public class BDCliente
    {
        //Destructor da Classe
        ~BDCliente()
        {
        }

        /***********************************************************************
        * NOME          :  Incluir          
        * METODO        :  Responsável por incluir o registro na tabela.
        *                  Inclui um registro na tabela TB_Genero         
        * DT CRIAÇÃO    :  07/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public int Incluir(Cliente aobjCliente)
        {
            //(07/05/2019-mfacine) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "INSERT INTO TB_CLIENTE" +
                            "(" +
                            "SNM_CLIENTE   , " +
                            "SCPF_CLIENTE  , " +
                            "SRG_CLIENTE   , " +
                            "SEND_CLIENTE  , " +
                            "SFN_CLIENTE   , " +
                            "SMAIL_CLIENTE " +
                            ")" +
                            "VALUES " +
                            "(" +
                            "@SNM_CLIENTE   , " +
                            "@SCPF_CLIENTE  , " +
                            "@SRG_CLIENTE   , " +
                            "@SEND_CLIENTE  , " +
                            "@SFN_CLIENTE   , " +
                            "@SMAIL_CLIENTE " +
                            ");" +
                            "SELECT IDENT_CURRENT('TB_CLIENTE') as 'id'";

            //ToDo: Continuar Daqui.

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@SNM_CLIENTE", aobjCliente.NM_CLIENTE);
            objCmd.Parameters.AddWithValue("@SCPF_CLIENTE", aobjCliente.CPF_CLIENTE);
            objCmd.Parameters.AddWithValue("@SRG_CLIENTE", aobjCliente.RG_CLIENTE);
            objCmd.Parameters.AddWithValue("@SEND_CLIENTE", aobjCliente.END_CLIENTE);
            objCmd.Parameters.AddWithValue("@SFN_CLIENTE", aobjCliente.FN_CLIENTE);
            objCmd.Parameters.AddWithValue("@SMAIL_CLIENTE", aobjCliente.MAIL_CLIENTE);

            try
            {
                //(20.03.2019-mfacine) Abro a Conexão com o BD
                objCon.Open();

                //(20.03.2019-mfacine) Executo o comando de forma escalar
                int _id = Convert.ToInt16(objCmd.ExecuteScalar());

                //(20.03.2019-mfacine) Fecho a Conexão com o BD
                objCon.Close();

                return _id;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }


        /***********************************************************************
        * NOME          :  Alterar          
        * METODO        :  Responsável por alterar o registro na tabela.
        *                  Alterar um registro na tabela TB_Genero         
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Boolean Alterar(Cliente aobjCliente)
        {
            if (aobjCliente.COD_CLIENTE != -1)
            {

                SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

                string varsql = "UPDATE TB_CLIENTE SET " +
                    "SNM_CLIENTE   = @SNM_CLIENTE,     " +
                    "SCPF_CLIENTE  = @SCPF_CLIENTE,    " +
                    "SRG_CLIENTE   = @SRG_CLIENTE,     " +
                    "SEND_CLIENTE  = @SEND_CLIENTE,    " +
                    "SFN_CLIENTE   = @SFN_CLIENTE,     " +
                    "SMAIL_CLIENTE = @SMAIL_CLIENTE   " +
                    " WHERE ICOD_CLIENTE = @ICOD_CLIENTE ";

                SqlCommand objCmd = new SqlCommand(varsql, objCon);
                objCmd.Parameters.AddWithValue("@ICOD_CLIENTE", aobjCliente.COD_CLIENTE);
                objCmd.Parameters.AddWithValue("@SNM_CLIENTE", aobjCliente.NM_CLIENTE);
                objCmd.Parameters.AddWithValue("@SCPF_CLIENTE", aobjCliente.CPF_CLIENTE);
                objCmd.Parameters.AddWithValue("@SRG_CLIENTE", aobjCliente.RG_CLIENTE);
                objCmd.Parameters.AddWithValue("@SEND_CLIENTE", aobjCliente.END_CLIENTE);
                objCmd.Parameters.AddWithValue("@SFN_CLIENTE", aobjCliente.FN_CLIENTE);
                objCmd.Parameters.AddWithValue("@SMAIL_CLIENTE", aobjCliente.MAIL_CLIENTE);

                try
                {
                    objCon.Open();
                    objCmd.ExecuteNonQuery();
                    objCon.Close();
                    return true;
                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  Excluir          
        * METODO        :  Responsável por deletar o registro na tabela TB_Genero          
        * DT CRIAÇÃO    :  13/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Boolean Excluir(Cliente aobjCliente)
        {

            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varsql = "DELETE FROM TB_CLIENTE " +
                            " WHERE ICOD_CLIENTE = @ICOD_CLIENTE ";
            SqlCommand objCmd = new SqlCommand(varsql, objCon);

            objCmd.Parameters.AddWithValue("@ICOD_CLIENTE", aobjCliente.COD_CLIENTE);

            try
            {
                objCon.Open();
                objCmd.ExecuteNonQuery();
                objCon.Close();
                return true;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO NA EXCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  FindByGenero          
        * METODO        :  Responsável por encontrar o registro na tabela.
        *                  Encontra um registro na tabela TB_Genero          
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Cliente FindByCliente(Cliente aobjCliente)
        {
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "SELECT * FROM TB_CLIENTE " +
                            "WHERE ICOD_CLIENTE = @ICOD_CLIENTE";

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@ICOD_CLIENTE", aobjCliente.COD_CLIENTE);

            objCon.Open();

            SqlDataReader objDtr = objCmd.ExecuteReader();

            if (objDtr.HasRows)
            {
                objDtr.Read();

                aobjCliente.COD_CLIENTE = Convert.ToInt16(objDtr["ICOD_CLIENTE"]);
                aobjCliente.NM_CLIENTE = objDtr["SNM_CLIENTE"].ToString();
                aobjCliente.CPF_CLIENTE = objDtr["SCPF_CLIENTE"].ToString();
                aobjCliente.RG_CLIENTE = objDtr["SRG_CLIENTE"].ToString();
                aobjCliente.END_CLIENTE = objDtr["SEND_CLIENTE"].ToString();
                aobjCliente.FN_CLIENTE = objDtr["SFN_CLIENTE"].ToString();
                aobjCliente.MAIL_CLIENTE = objDtr["SMAIL_CLIENTE"].ToString();

                objCon.Close();
                objDtr.Close();
                return aobjCliente;
            }

            else
            {
                objCon.Close();
                objDtr.Close();
                return null;
            }
        }

        /***********************************************************************
        * NOME          :  FindAllGenero  
        * METODO        :  Responsável por encontrar todos os Objetos na Base 
        *                  de Dados. Busca todos os registros na tabela TB_Genero.         
        * DT CRIAÇÃO    :  13/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Monstro (mFacine) 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public List<Cliente> FindAllCliente()
        {
            //(13.05.2019-mfacine) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            //(13.05.2019-mfacine) Cria a variável que conterá o comando SQL
            string varSql = "SELECT * FROM TB_CLIENTE";

            //(13.05.2019-mfacine) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);

            //(13.05.2019-mfacine) Abre a conexão com o banco de dados
            objCon.Open();

            //(13.05.2019-mfacine) Executa o comando para excluir o registro
            SqlDataReader objDtr = objCmd.ExecuteReader();

            List<Cliente> lista = new List<Cliente>();

            if (objDtr.HasRows)
            {
                //(20.03.2019-mfacine) Enquanto tiver linha faça
                while (objDtr.Read())
                {
                    //(20.03.2019-mfacine) Instância do objto Receita
                    Cliente aobjCliente = new Cliente();

                    //(20.03.2019-mfacine) Coloca os dados do Reader no Objeto
                    aobjCliente.COD_CLIENTE = Convert.ToInt16(objDtr["ICOD_CLIENTE"]);
                    aobjCliente.NM_CLIENTE = objDtr["SNM_CLIENTE"].ToString();
                    aobjCliente.CPF_CLIENTE = objDtr["SCPF_CLIENTE"].ToString();
                    aobjCliente.RG_CLIENTE = objDtr["SRG_CLIENTE"].ToString();
                    aobjCliente.END_CLIENTE = objDtr["SEND_CLIENTE"].ToString();
                    aobjCliente.FN_CLIENTE = objDtr["SFN_CLIENTE"].ToString();
                    aobjCliente.MAIL_CLIENTE = objDtr["SMAIL_CLIENTE"].ToString();

                    lista.Add(aobjCliente);
                }
                //(20.03.2019-mfacine) Fecha a conexão com o banco de dados
                objCon.Close();

                //(20.03.2019-mfacine) Fecha o objeto Reader
                objDtr.Close();

                return lista;
            }
            else
            {
                //(20.03.2019-mfacine) Fecha a conexão com o banco de dados
                objCon.Close();

                //(20.03.2019-mfacine) Fecha o objeto Reader
                objDtr.Close();

                return null;
            }

        }

    }
}
