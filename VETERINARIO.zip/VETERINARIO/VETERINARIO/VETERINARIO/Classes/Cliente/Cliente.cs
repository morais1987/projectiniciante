﻿/**********************************************************************************
 * NOME:            Animal
 * CLASSE:          Representação da entidade Animal 
 * DT CRIAÇÃO:      06/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Guilherme / Jose Henrique
 * OBSERVAÇÕES:     Atributos privados com métodos Get e Set públicos
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VETERINARIO
{
    public class Cliente
    {
        //(Guilherme / Jose Henrique  - 06/05/2019) Metodo de Destruição da Classe
        ~Cliente()
        {
        }

        //(Guilherme / Jose Henrique  - 06/05/2019) Atributos/Propriedades Privadas Encapsuladas
        private int vcod_Cliente = -1;
        private string vnm_Cliente = null;
        private string vcpf_Cliente = null;
        private string vrg_Cliente = null;
        private string vend_Cliente = null;
        private string vfn_Cliente = null;
        private string vmail_Cliente = null;

        //( - 06/05/2019) Metodos/Ações Publicas

        /***********************************************************************
         * NOME:            COD_CLIENTE    
         * METODO:          Representação do atributo Código com os métodos 
         *                  Get e Set          
         * DT CRIAÇÃO:      11/06/2019    
         * DT ALTERAÇÃO:    -
         * ESCRITA POR:     Guilherme / Jose Henrique 
         **********************************************************************/
        public int COD_CLIENTE
        {
            get { return vcod_Cliente; }
            set { vcod_Cliente = value; }
        }

        /***********************************************************************
        * NOME:              NM_CLIENTE
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public string NM_CLIENTE
        {
            get { return vnm_Cliente; }
            set { vnm_Cliente = value; }
        }

        /***********************************************************************
        * NOME:              NM_CLIENTE
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public string CPF_CLIENTE
        {
            get { return vcpf_Cliente; }
            set { vcpf_Cliente = value; }
        }

        /***********************************************************************
        * NOME:              NM_CLIENTE
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public string RG_CLIENTE
        {
            get { return vrg_Cliente; }
            set { vrg_Cliente = value; }
        }

        /***********************************************************************
        * NOME:              NM_CLIENTE
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public string END_CLIENTE
        {
            get { return vend_Cliente; }
            set { vend_Cliente = value; }
        }

        /***********************************************************************
        * NOME:              NM_CLIENTE
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public string FN_CLIENTE
        {
            get { return vfn_Cliente; }
            set { vfn_Cliente = value; }
        }

        /***********************************************************************
        * NOME:              NM_CLIENTE
        * METODO:          Representação do atributo Nome com os métodos 
        *                  Get e Set          
        * DT CRIAÇÃO:      11/06/2019    
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Guilherme / Jose Henrique 
        **********************************************************************/
        public string MAIL_CLIENTE
        {
            get { return vmail_Cliente; }
            set { vmail_Cliente = value; }
        }
    }
}

