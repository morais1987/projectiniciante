﻿/**********************************************************************************
 * NOME:            BDRaca
 * CLASSE:          Representação da classe de banco de dados Raca
 * DT CRIAÇÃO:      13/05/2019
 * DT ALTERAÇÃO:    -
 * ESCRITA POR:     Guilherme / Jose Henrique
 * OBSERVAÇÕES:     
 * ********************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace VETERINARIO
{
    public class BDRaca
    {

        //Destructor da Classe
        ~BDRaca()
        {
        }

        /***********************************************************************
        * NOME          :  Incluir          
        * METODO        :  Responsável por incluir o registro na tabela.
        *                  Inclui um registro na tabela TEB_RACA         
        * DT CRIAÇÃO    :  07/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public int Incluir(Raca aobjRaca)
        {



            //(17/06/19 Guilherme/Jose) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "INSERT INTO TB_RACA" +
                            "(" +
                            "SDESC_RACA  " +
                            ")" +
                            "VALUES " +
                            "(" +
                            "@SDESC_RACA  " +

                            ");" +
                            "SELECT IDENT_CURRENT('TB_RACA') as 'id'";

            //ToDo: Continuar Daqui.

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@SDESC_RACA", aobjRaca.DESC_RACA);


            try
            {
                //(12.06.2019-Guilherme/Jose) Abro a Conexão com o BD
                objCon.Open();

                //(12.06.2019-Guilherme/Jose) Executo o comando de forma escalar
                int _id = Convert.ToInt16(objCmd.ExecuteScalar());

                //(12.06.2019-Guilherme/Jose) Fecho a Conexão com o BD
                objCon.Close();

                return _id;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO FATAL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }


        /***********************************************************************
        * NOME          :  Alterar          
        * METODO        :  Responsável por alterar o registro na tabela.
        *                  Alterar um registro na tabela TEB_RACA         
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Boolean Alterar(Raca aobjRaca)
        {
            if (aobjRaca.COD_RACA != -1)
            {

                SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

                string varsql = "UPDATE TB_RACA SET " +
                    "SDESC_RACA   = @SDESC_RACA " +
                    " WHERE ICOD_RACA = @ICOD_RACA ";

                SqlCommand objCmd = new SqlCommand(varsql, objCon);
                objCmd.Parameters.AddWithValue("@ICOD_RACA", aobjRaca.COD_RACA);
                objCmd.Parameters.AddWithValue("@SDESC_RACA", aobjRaca.DESC_RACA);


                try
                {
                    objCon.Open();
                    objCmd.ExecuteNonQuery();
                    objCon.Close();
                    return true;
                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  Excluir          
        * METODO        :  Responsável por deletar o registro na tabela TEB_RACA          
        * DT CRIAÇÃO    :  13/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Boolean Excluir(Raca aobjRaca)
        {

            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varsql = "DELETE FROM TB_RACA " +
                            " WHERE ICOD_RACA = @ICOD_RACA ";
            SqlCommand objCmd = new SqlCommand(varsql, objCon);

            objCmd.Parameters.AddWithValue("@ICOD_RACA", aobjRaca.COD_RACA);

            try
            {
                objCon.Open();
                objCmd.ExecuteNonQuery();
                objCon.Close();
                return true;
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO NA EXCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /***********************************************************************
        * NOME          :  FindByVETERINARIO          
        * METODO        :  Responsável por encontrar o registro na tabela.
        *                  Encontra um registro na tabela TEB_RACA          
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Raca FindByRaca(Raca aobjRaca)
        {
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "SELECT * FROM TB_RACA " +
                            "WHERE ICOD_RACA = @ICOD_RACA";

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@ICOD_RACA", aobjRaca.COD_RACA);

            objCon.Open();

            SqlDataReader objDtr = objCmd.ExecuteReader();

            if (objDtr.HasRows)
            {
                objDtr.Read();

                aobjRaca.COD_RACA = Convert.ToInt16(objDtr["ICOD_RACA"]);
                aobjRaca.DESC_RACA = objDtr["SDESC_RACA"].ToString();



                objCon.Close();
                objDtr.Close();
                return aobjRaca;
            }

            else
            {
                objCon.Close();
                objDtr.Close();
                return null;
            }
        }

        /***********************************************************************
        * NOME          :  FindByPET       
        * METODO        :  Responsável por encontrar o registro na tabela.
        *                  Encontra um registro na tabela TEB_RACA          
        * DT CRIAÇÃO    :  10/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public Raca FindAllRaca(Raca aobjRaca)
        {
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            string varSql = "SELECT * FROM TEB_RACA " +
                            "WHERE ICOD_RACA = @ICOD_RACA";

            SqlCommand objCmd = new SqlCommand(varSql, objCon);
            objCmd.Parameters.AddWithValue("@ICOD_RACA", aobjRaca.COD_RACA);

            objCon.Open();

            SqlDataReader objDtr = objCmd.ExecuteReader();

            if (objDtr.HasRows)
            {
                objDtr.Read();

                aobjRaca.COD_RACA = Convert.ToInt16(objDtr["ICOD_RACA"]);
                aobjRaca.DESC_RACA = objDtr["SDESC_RACA"].ToString();



                objCon.Close();
                objDtr.Close();
                return aobjRaca;
            }

            else
            {
                objCon.Close();
                objDtr.Close();
                return null;
            }
        }



        /***********************************************************************
        * NOME          :  FindAllUSUARIO  
        * METODO        :  Responsável por encontrar todos os Objetos na Base 
        *                  de Dados. Busca todos os registros na tabela TEB_RACA.         
        * DT CRIAÇÃO    :  13/05/2019    
        * DT ALTERAÇÃO  :  -
        * ESCRITA POR   :  Guilherme / Jose Henrique 
        * OBSERVAÇÕES   :  Utiliza a Classe Connection para acessar o BD.   
        **********************************************************************/
        public List<Raca> FindAllRaca()
        {
            //(17/06/19 Guilherme/Jose) Cria objeto para a conexão com o banco de dados
            SqlConnection objCon = new SqlConnection(Connection.ConnectionPath());

            //(17/06/19 Guilherme/Jose) Cria a variável que conterá o comando SQL
            string varSql = "SELECT * FROM TB_RACA";

            //(17/06/19 Guilherme/Jose) Cria o objeto que executa o comando
            SqlCommand objCmd = new SqlCommand(varSql, objCon);

            //(17/06/19 Guilherme/Jose) Abre a conexão com o banco de dados
            objCon.Open();

            //(17/06/19 Guilherme/Jose) Executa o comando para excluir o registro
            SqlDataReader objDtr = objCmd.ExecuteReader();

            List<Raca> lista = new List<Raca>();

            if (objDtr.HasRows)
            {
                //(12.06.2019-Guilherme/Jose) Enquanto tiver linha faça
                while (objDtr.Read())
                {
                    //(12.06.2019-Guilherme/Jose) Instância do objto Receita
                    Raca aobjRaca = new Raca();

                    //(12.06.2019-Guilherme/Jose) Coloca os dados do Reader no Objeto
                    aobjRaca.DESC_RACA = objDtr["SDESC_RACA"].ToString();
                    aobjRaca.COD_RACA = Convert.ToInt16(objDtr["ICOD_RACA"]);



                    lista.Add(aobjRaca);
                }
                //(12.06.2019-Guilherme/Jose) Fecha a conexão com o banco de dados
                objCon.Close();

                //(12.06.2019-Guilherme/Jose) Fecha o objeto Reader
                objDtr.Close();

                return lista;
            }
            else
            {
                //(12.06.2019-Guilherme/Jose) Fecha a conexão com o banco de dados
                objCon.Close();

                //(12.06.2019-Guilherme/Jose) Fecha o objeto Reader
                objDtr.Close();

                return null;
            }

        }

    }
}
