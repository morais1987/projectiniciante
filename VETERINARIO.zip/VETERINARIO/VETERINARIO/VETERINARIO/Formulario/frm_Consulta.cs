﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VETERINARIO
{
    public partial class frm_Consulta : Form
    {
        public frm_Consulta()
        {
            InitializeComponent();
        }

        private void text_cod_Consulta_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Novo_Click(object sender, EventArgs e)
        {

        }
    }
}
