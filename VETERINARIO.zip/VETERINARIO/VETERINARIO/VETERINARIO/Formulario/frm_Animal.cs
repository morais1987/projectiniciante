﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VETERINARIO
{
    public partial class frm_Animal : Form
    {
        FuncGeral obj_FuncGeral = new FuncGeral();
        Animal Animal_Principal = new Animal();

        public frm_Animal()
        {
            InitializeComponent();
            PopulaLista();
            obj_FuncGeral.StatusBtn(this, 0);
            obj_FuncGeral.HabilitaTela(this, false);
        }



        /**********************************************************************************
        * NOME:            PopulaLista
        * CLASSE:          Preenche o listbox com os dados dos Usuarioes cadastrados no Banco
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaLista()
        {
            BDAnimal obj_BDAnimal = new BDAnimal();
            List<Animal> Lista = new List<Animal>();

            lbox_Animal.Items.Clear();

            Lista = obj_BDAnimal.FindAllAnimal();

            if (Lista != null)
            {
                for (int i = 0; i <= Lista.Count - 1; i++)
                {
                    lbox_Animal.Items.Add(Convert.ToString(Lista[i].COD_ANIMAL) + "-" + Lista[i].DESC_ANIMAL);
                }
            }
        }

        /**********************************************************************************
        * NOME:            PopulaTela
        * CLASSE:          Preenche o objeto Usuario no formulário
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * PARAMETRO:       Objeto Usuario 
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaTela(Animal obj_Animal)
        {
            if (obj_Animal.COD_ANIMAL != -1)
            {
                tbox_cod_Animal.Text = Convert.ToString(obj_Animal.COD_ANIMAL);
            }
            tbox_Desc_Animal.Text = obj_Animal.DESC_ANIMAL;
        }

        /**********************************************************************************
        * NOME:            PopulaObjeto
        * CLASSE:          Preenche o objeto Usuario com os dados do formulário
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private Animal PopulaObjeto()
        {
            Animal obj_Animal = new Animal();

            if (lbox_Animal.Text == "")
            {
                obj_Animal.DESC_ANIMAL = tbox_Desc_Animal.Text;
            }
            else
            {
                obj_Animal.COD_ANIMAL = Convert.ToInt16(tbox_cod_Animal.Text);
                obj_Animal.DESC_ANIMAL = tbox_Desc_Animal.Text;
            }

            return obj_Animal;
        }

        private void lbox_Animal_DoubleClick(object sender, EventArgs e)
        {
            BDAnimal obj_BDAnimal = new BDAnimal();
            string slinha = lbox_Animal.Items[lbox_Animal.SelectedIndex].ToString();

            int ipos = 0;

            for (int t = 0; t <= slinha.Length; t++)
            {
                if (slinha.Substring(t, 1) == "-")
                {
                    ipos = t;
                    break;
                }
            }
            Animal_Principal.COD_ANIMAL = Convert.ToInt16(slinha.Substring(0, ipos));

            Animal_Principal = obj_BDAnimal.FindByAnimal(Animal_Principal);
            PopulaTela(Animal_Principal);
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);
        }

        private void btn_Novo_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.LimpaTela(this);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_Desc_Animal.Focus();
        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_Desc_Animal.Focus();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            BDAnimal obj_BDAnimal = new BDAnimal();

            DialogResult varResp = MessageBox.Show("Confirma a Exclusão?", "EXCLUSÃO DO Usuario", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (varResp == DialogResult.Yes)
            {
                Animal_Principal = PopulaObjeto();

                if (obj_BDAnimal.Excluir(Animal_Principal))
                {
                    MessageBox.Show("Usuario excluido com sucesso.", "EXCLUSÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                obj_FuncGeral.LimpaTela(this);
                obj_FuncGeral.HabilitaTela(this, false);
                obj_FuncGeral.StatusBtn(this, 0);
                PopulaLista();
            }
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {
            BDAnimal obj_BDAnimal = new BDAnimal();

            Animal_Principal = PopulaObjeto();

            if (Animal_Principal.COD_ANIMAL != -1)
            {
                obj_BDAnimal.Alterar(Animal_Principal);
                MessageBox.Show("Usuario alterado com sucesso.", "ALTERAÇÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                tbox_cod_Animal.Text = Convert.ToString(obj_BDAnimal.Incluir(Animal_Principal));
                MessageBox.Show("Usuario incluido com sucesso.", "INCLUSÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            obj_FuncGeral.StatusBtn(this, 1);
            obj_FuncGeral.HabilitaTela(this, false);
            PopulaLista();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);
            PopulaTela(Animal_Principal);
        }

        private void frm_Animal_Load(object sender, EventArgs e)
        {

        }
    }
}
