﻿namespace VETERINARIO
{
    partial class frm_Cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Titulo = new System.Windows.Forms.Panel();
            this.label = new System.Windows.Forms.Label();
            this.pnl_Button = new System.Windows.Forms.Panel();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Confirmar = new System.Windows.Forms.Button();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.btn_Novo = new System.Windows.Forms.Button();
            this.lbox_Cliente = new System.Windows.Forms.ListBox();
            this.pnl_Detalhe = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbox_mail_Cliente = new System.Windows.Forms.TextBox();
            this.tbox_fn_Cliente = new System.Windows.Forms.TextBox();
            this.tbox_end_Cliente = new System.Windows.Forms.TextBox();
            this.tbox_rg_Cliente = new System.Windows.Forms.TextBox();
            this.tbox_cpf_Cliente = new System.Windows.Forms.TextBox();
            this.tbox_nm_Cliente = new System.Windows.Forms.TextBox();
            this.tbox_cod_Cliente = new System.Windows.Forms.TextBox();
            this.pnl_Titulo.SuspendLayout();
            this.pnl_Button.SuspendLayout();
            this.pnl_Detalhe.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Titulo
            // 
            this.pnl_Titulo.BackColor = System.Drawing.Color.LightSeaGreen;
            this.pnl_Titulo.Controls.Add(this.label);
            this.pnl_Titulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Titulo.Location = new System.Drawing.Point(0, 0);
            this.pnl_Titulo.Name = "pnl_Titulo";
            this.pnl_Titulo.Size = new System.Drawing.Size(708, 70);
            this.pnl_Titulo.TabIndex = 0;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.Color.Black;
            this.label.Location = new System.Drawing.Point(41, 9);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(173, 55);
            this.label.TabIndex = 0;
            this.label.Text = "Cliente";
            // 
            // pnl_Button
            // 
            this.pnl_Button.BackColor = System.Drawing.Color.MediumTurquoise;
            this.pnl_Button.Controls.Add(this.btn_Excluir);
            this.pnl_Button.Controls.Add(this.btn_Cancelar);
            this.pnl_Button.Controls.Add(this.btn_Confirmar);
            this.pnl_Button.Controls.Add(this.btn_Alterar);
            this.pnl_Button.Controls.Add(this.btn_Novo);
            this.pnl_Button.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_Button.Location = new System.Drawing.Point(0, 331);
            this.pnl_Button.Name = "pnl_Button";
            this.pnl_Button.Size = new System.Drawing.Size(708, 62);
            this.pnl_Button.TabIndex = 2;
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.Location = new System.Drawing.Point(213, 15);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(75, 23);
            this.btn_Excluir.TabIndex = 2;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = true;
            this.btn_Excluir.Click += new System.EventHandler(this.btn_Excluir_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Location = new System.Drawing.Point(536, 15);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancelar.TabIndex = 4;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // btn_Confirmar
            // 
            this.btn_Confirmar.Location = new System.Drawing.Point(455, 15);
            this.btn_Confirmar.Name = "btn_Confirmar";
            this.btn_Confirmar.Size = new System.Drawing.Size(75, 23);
            this.btn_Confirmar.TabIndex = 3;
            this.btn_Confirmar.Text = "Confirma";
            this.btn_Confirmar.UseVisualStyleBackColor = true;
            this.btn_Confirmar.Click += new System.EventHandler(this.btn_Confirmar_Click);
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.Location = new System.Drawing.Point(116, 15);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(75, 23);
            this.btn_Alterar.TabIndex = 1;
            this.btn_Alterar.Text = "Alterar";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            this.btn_Alterar.Click += new System.EventHandler(this.btn_Alterar_Click);
            // 
            // btn_Novo
            // 
            this.btn_Novo.Location = new System.Drawing.Point(24, 15);
            this.btn_Novo.Name = "btn_Novo";
            this.btn_Novo.Size = new System.Drawing.Size(75, 23);
            this.btn_Novo.TabIndex = 0;
            this.btn_Novo.Text = "Novo";
            this.btn_Novo.UseVisualStyleBackColor = true;
            this.btn_Novo.Click += new System.EventHandler(this.btn_Novo_Click);
            // 
            // lbox_Cliente
            // 
            this.lbox_Cliente.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbox_Cliente.FormattingEnabled = true;
            this.lbox_Cliente.Location = new System.Drawing.Point(0, 70);
            this.lbox_Cliente.Name = "lbox_Cliente";
            this.lbox_Cliente.Size = new System.Drawing.Size(191, 261);
            this.lbox_Cliente.TabIndex = 0;
            this.lbox_Cliente.DoubleClick += new System.EventHandler(this.lbox_Cliente_DoubleClick);
            // 
            // pnl_Detalhe
            // 
            this.pnl_Detalhe.BackColor = System.Drawing.Color.PaleTurquoise;
            this.pnl_Detalhe.Controls.Add(this.label7);
            this.pnl_Detalhe.Controls.Add(this.label6);
            this.pnl_Detalhe.Controls.Add(this.label5);
            this.pnl_Detalhe.Controls.Add(this.label4);
            this.pnl_Detalhe.Controls.Add(this.label3);
            this.pnl_Detalhe.Controls.Add(this.label2);
            this.pnl_Detalhe.Controls.Add(this.label1);
            this.pnl_Detalhe.Controls.Add(this.tbox_mail_Cliente);
            this.pnl_Detalhe.Controls.Add(this.tbox_fn_Cliente);
            this.pnl_Detalhe.Controls.Add(this.tbox_end_Cliente);
            this.pnl_Detalhe.Controls.Add(this.tbox_rg_Cliente);
            this.pnl_Detalhe.Controls.Add(this.tbox_cpf_Cliente);
            this.pnl_Detalhe.Controls.Add(this.tbox_nm_Cliente);
            this.pnl_Detalhe.Controls.Add(this.tbox_cod_Cliente);
            this.pnl_Detalhe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Detalhe.Location = new System.Drawing.Point(191, 70);
            this.pnl_Detalhe.Name = "pnl_Detalhe";
            this.pnl_Detalhe.Size = new System.Drawing.Size(517, 261);
            this.pnl_Detalhe.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 197);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Email";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Fone";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Endereço";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "RG";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "CPF";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Nome";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Codigo";
            // 
            // tbox_mail_Cliente
            // 
            this.tbox_mail_Cliente.Location = new System.Drawing.Point(90, 194);
            this.tbox_mail_Cliente.Name = "tbox_mail_Cliente";
            this.tbox_mail_Cliente.Size = new System.Drawing.Size(165, 20);
            this.tbox_mail_Cliente.TabIndex = 7;
            // 
            // tbox_fn_Cliente
            // 
            this.tbox_fn_Cliente.Location = new System.Drawing.Point(90, 164);
            this.tbox_fn_Cliente.Name = "tbox_fn_Cliente";
            this.tbox_fn_Cliente.Size = new System.Drawing.Size(100, 20);
            this.tbox_fn_Cliente.TabIndex = 6;
            // 
            // tbox_end_Cliente
            // 
            this.tbox_end_Cliente.Location = new System.Drawing.Point(90, 138);
            this.tbox_end_Cliente.Name = "tbox_end_Cliente";
            this.tbox_end_Cliente.Size = new System.Drawing.Size(165, 20);
            this.tbox_end_Cliente.TabIndex = 5;
            // 
            // tbox_rg_Cliente
            // 
            this.tbox_rg_Cliente.Location = new System.Drawing.Point(90, 112);
            this.tbox_rg_Cliente.Name = "tbox_rg_Cliente";
            this.tbox_rg_Cliente.Size = new System.Drawing.Size(100, 20);
            this.tbox_rg_Cliente.TabIndex = 4;
            // 
            // tbox_cpf_Cliente
            // 
            this.tbox_cpf_Cliente.Location = new System.Drawing.Point(90, 86);
            this.tbox_cpf_Cliente.Name = "tbox_cpf_Cliente";
            this.tbox_cpf_Cliente.Size = new System.Drawing.Size(100, 20);
            this.tbox_cpf_Cliente.TabIndex = 3;
            // 
            // tbox_nm_Cliente
            // 
            this.tbox_nm_Cliente.Location = new System.Drawing.Point(90, 60);
            this.tbox_nm_Cliente.Name = "tbox_nm_Cliente";
            this.tbox_nm_Cliente.Size = new System.Drawing.Size(223, 20);
            this.tbox_nm_Cliente.TabIndex = 2;
            // 
            // tbox_cod_Cliente
            // 
            this.tbox_cod_Cliente.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.tbox_cod_Cliente.Location = new System.Drawing.Point(90, 34);
            this.tbox_cod_Cliente.Name = "tbox_cod_Cliente";
            this.tbox_cod_Cliente.Size = new System.Drawing.Size(100, 20);
            this.tbox_cod_Cliente.TabIndex = 0;
            // 
            // frm_Cliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 393);
            this.Controls.Add(this.pnl_Detalhe);
            this.Controls.Add(this.lbox_Cliente);
            this.Controls.Add(this.pnl_Button);
            this.Controls.Add(this.pnl_Titulo);
            this.Name = "frm_Cliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro_Cliente";
            this.pnl_Titulo.ResumeLayout(false);
            this.pnl_Titulo.PerformLayout();
            this.pnl_Button.ResumeLayout(false);
            this.pnl_Detalhe.ResumeLayout(false);
            this.pnl_Detalhe.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Titulo;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Panel pnl_Button;
        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Confirmar;
        private System.Windows.Forms.Button btn_Alterar;
        private System.Windows.Forms.Button btn_Novo;
        private System.Windows.Forms.ListBox lbox_Cliente;
        private System.Windows.Forms.Panel pnl_Detalhe;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbox_mail_Cliente;
        private System.Windows.Forms.TextBox tbox_fn_Cliente;
        private System.Windows.Forms.TextBox tbox_end_Cliente;
        private System.Windows.Forms.TextBox tbox_rg_Cliente;
        private System.Windows.Forms.TextBox tbox_cpf_Cliente;
        private System.Windows.Forms.TextBox tbox_nm_Cliente;
        private System.Windows.Forms.TextBox tbox_cod_Cliente;
    }
}