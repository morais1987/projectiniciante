﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VETERINARIO
{
    public partial class frm_Principal : Form
    {
        public frm_Principal()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void emprestimoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_Consulta obj_frm_Consulta = new frm_Consulta();
            obj_frm_Consulta.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Cliente_Click(object sender, EventArgs e)
        {
            frm_Cliente obj_frm_Cliente = new frm_Cliente();
            obj_frm_Cliente.ShowDialog();
        }

        private void petToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_Pet obj_frm_Pet = new frm_Pet();
            obj_frm_Pet.ShowDialog();
        }

        private void Animal_Click(object sender, EventArgs e)
        {
            frm_Animal obj_frm_Animal = new frm_Animal();
            obj_frm_Animal.ShowDialog();
        }

        private void veterinarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_Veterinario obj_frm_Veterinario = new frm_Veterinario();
            obj_frm_Veterinario.ShowDialog();
        }

        private void raçaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            frm_Raca obj_frm_Raca = new frm_Raca();
            obj_frm_Raca.ShowDialog();
        }
    }
}
