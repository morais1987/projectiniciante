﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VETERINARIO
{
    public partial class frm_Veterinario : Form
    {
        FuncGeral obj_FuncGeral = new FuncGeral();
        Veterinario Veterinario_Principal = new Veterinario();

        public frm_Veterinario()
        {
            InitializeComponent();
            PopulaLista();
            obj_FuncGeral.StatusBtn(this, 0);
            obj_FuncGeral.HabilitaTela(this, false);
        }

        /**********************************************************************************
        * NOME:            PopulaLista
        * CLASSE:          Preenche o listbox com os dados dos Usuarioes cadastrados no Banco
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaLista()
        {
            BDVeterinario obj_BDVeterinario = new BDVeterinario();
            List<Veterinario> Lista = new List<Veterinario>();

            lbox_Veterinario.Items.Clear();

            Lista = obj_BDVeterinario.FindAllVeterinario();

            if (Lista != null)
            {
                for (int i = 0; i <= Lista.Count - 1; i++)
                {
                    lbox_Veterinario.Items.Add(Convert.ToString(Lista[i].COD_VETERINARIO) + "-" + Lista[i].NM_VETERINARIO);
                }
            }
        }

        /**********************************************************************************
       * NOME:            PopulaTela
       * CLASSE:          Preenche o objeto Usuario no formulário
       * DT CRIAÇÃO:      28/05/2019
       * DT ALTERAÇÃO:    -
       * PARAMETRO:       Objeto Usuario 
       * ESCRITA POR:     Monstro (mFacine)
       * OBSERVAÇÕES:     
       * ********************************************************************************/
        private void PopulaTela(Veterinario obj_Veterinario)
        {
            if (obj_Veterinario.COD_VETERINARIO != -1)
            {
                tbox_cod_Veterinario.Text = Convert.ToString(obj_Veterinario.COD_VETERINARIO);
            }
            tbox_nm_Veterinario.Text = obj_Veterinario.NM_VETERINARIO;
            tbox_Fone_Veterinario.Text = obj_Veterinario.FN_VETERINARIO;
        }

        /**********************************************************************************
        * NOME:            PopulaObjeto
        * CLASSE:          Preenche o objeto Usuario com os dados do formulário
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private Veterinario PopulaObjeto()
        {
            Veterinario obj_Veterinario = new Veterinario();

            if (tbox_cod_Veterinario.Text == "")
            {
                obj_Veterinario.NM_VETERINARIO = tbox_nm_Veterinario.Text;
                obj_Veterinario.FN_VETERINARIO = tbox_Fone_Veterinario.Text;
            }
            else
            {
                obj_Veterinario.COD_VETERINARIO = Convert.ToInt16(tbox_cod_Veterinario.Text);
                obj_Veterinario.NM_VETERINARIO = tbox_nm_Veterinario.Text;
                obj_Veterinario.FN_VETERINARIO = tbox_Fone_Veterinario.Text;
            }

            return obj_Veterinario;
        }

        private void lbox_Veterinario_DoubleClick(object sender, EventArgs e)
        {
            BDVeterinario obj_BDVeterinario = new BDVeterinario();
            string slinha = lbox_Veterinario.Items[lbox_Veterinario.SelectedIndex].ToString();

            int ipos = 0;

            for (int t = 0; t <= slinha.Length; t++)
            {
                if (slinha.Substring(t, 1) == "-")
                {
                    ipos = t;
                    break;
                }
            }
            Veterinario_Principal.COD_VETERINARIO = Convert.ToInt16(slinha.Substring(0, ipos));

            Veterinario_Principal = obj_BDVeterinario.FindByVeterinario(Veterinario_Principal);
            PopulaTela(Veterinario_Principal);
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);
        }

        private void btn_Novo_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.LimpaTela(this);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_nm_Veterinario.Focus();
        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_nm_Veterinario.Focus();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            BDVeterinario obj_BDVeterinario = new BDVeterinario();

            DialogResult varResp = MessageBox.Show("Confirma a Exclusão?", "EXCLUSÃO DO Usuario", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (varResp == DialogResult.Yes)
            {
                Veterinario_Principal = PopulaObjeto();

                if (obj_BDVeterinario.Excluir(Veterinario_Principal))
                {
                    MessageBox.Show("Usuario excluido com sucesso.", "EXCLUSÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                obj_FuncGeral.LimpaTela(this);
                obj_FuncGeral.HabilitaTela(this, false);
                obj_FuncGeral.StatusBtn(this, 0);
                PopulaLista();
            }
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);
            PopulaTela(Veterinario_Principal);
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {
            BDVeterinario obj_BDVeterinario = new BDVeterinario();

            Veterinario_Principal = PopulaObjeto();

            if (Veterinario_Principal.COD_VETERINARIO != -1)
            {
                obj_BDVeterinario.Alterar(Veterinario_Principal);
                MessageBox.Show("Usuario alterado com sucesso.", "ALTERAÇÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                tbox_cod_Veterinario.Text = Convert.ToString(obj_BDVeterinario.Incluir(Veterinario_Principal));
                MessageBox.Show("Usuario incluido com sucesso.", "INCLUSÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            obj_FuncGeral.StatusBtn(this, 1);
            obj_FuncGeral.HabilitaTela(this, false);
            PopulaLista();
        }
    }
}