﻿namespace VETERINARIO
{
    partial class frm_Consulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Confirma = new System.Windows.Forms.Button();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.btn_Novo = new System.Windows.Forms.Button();
            this.lbox_Consulta = new System.Windows.Forms.ListBox();
            this.pnl_Animal = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.text_Cod_Pet = new System.Windows.Forms.TextBox();
            this.text_Data = new System.Windows.Forms.TextBox();
            this.text_Hora = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.text_cod_veterinario = new System.Windows.Forms.TextBox();
            this.text_cod_Consulta = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnl_Animal.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel1.Controls.Add(this.label);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(649, 70);
            this.panel1.TabIndex = 5;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.Color.Black;
            this.label.Location = new System.Drawing.Point(41, 9);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(214, 55);
            this.label.TabIndex = 0;
            this.label.Text = "Consulta";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Turquoise;
            this.panel2.Controls.Add(this.btn_Excluir);
            this.panel2.Controls.Add(this.btn_Cancelar);
            this.panel2.Controls.Add(this.btn_Confirma);
            this.panel2.Controls.Add(this.btn_Alterar);
            this.panel2.Controls.Add(this.btn_Novo);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 325);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(649, 71);
            this.panel2.TabIndex = 6;
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.Location = new System.Drawing.Point(213, 22);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(75, 23);
            this.btn_Excluir.TabIndex = 4;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = true;
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Location = new System.Drawing.Point(536, 22);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancelar.TabIndex = 3;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            // 
            // btn_Confirma
            // 
            this.btn_Confirma.Location = new System.Drawing.Point(428, 22);
            this.btn_Confirma.Name = "btn_Confirma";
            this.btn_Confirma.Size = new System.Drawing.Size(75, 23);
            this.btn_Confirma.TabIndex = 2;
            this.btn_Confirma.Text = "Confirma";
            this.btn_Confirma.UseVisualStyleBackColor = true;
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.Location = new System.Drawing.Point(116, 22);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(75, 23);
            this.btn_Alterar.TabIndex = 1;
            this.btn_Alterar.Text = "Alterar";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            // 
            // btn_Novo
            // 
            this.btn_Novo.Location = new System.Drawing.Point(24, 22);
            this.btn_Novo.Name = "btn_Novo";
            this.btn_Novo.Size = new System.Drawing.Size(75, 23);
            this.btn_Novo.TabIndex = 0;
            this.btn_Novo.Text = "Novo";
            this.btn_Novo.UseVisualStyleBackColor = true;
            this.btn_Novo.Click += new System.EventHandler(this.btn_Novo_Click);
            // 
            // lbox_Consulta
            // 
            this.lbox_Consulta.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lbox_Consulta.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbox_Consulta.FormattingEnabled = true;
            this.lbox_Consulta.Location = new System.Drawing.Point(0, 70);
            this.lbox_Consulta.Name = "lbox_Consulta";
            this.lbox_Consulta.Size = new System.Drawing.Size(191, 255);
            this.lbox_Consulta.TabIndex = 8;
            // 
            // pnl_Animal
            // 
            this.pnl_Animal.BackColor = System.Drawing.Color.PaleTurquoise;
            this.pnl_Animal.Controls.Add(this.label7);
            this.pnl_Animal.Controls.Add(this.label6);
            this.pnl_Animal.Controls.Add(this.label4);
            this.pnl_Animal.Controls.Add(this.label5);
            this.pnl_Animal.Controls.Add(this.label3);
            this.pnl_Animal.Controls.Add(this.textBox5);
            this.pnl_Animal.Controls.Add(this.text_Cod_Pet);
            this.pnl_Animal.Controls.Add(this.text_Data);
            this.pnl_Animal.Controls.Add(this.text_Hora);
            this.pnl_Animal.Controls.Add(this.label2);
            this.pnl_Animal.Controls.Add(this.label1);
            this.pnl_Animal.Controls.Add(this.text_cod_veterinario);
            this.pnl_Animal.Controls.Add(this.text_cod_Consulta);
            this.pnl_Animal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Animal.Location = new System.Drawing.Point(191, 70);
            this.pnl_Animal.Name = "pnl_Animal";
            this.pnl_Animal.Size = new System.Drawing.Size(458, 255);
            this.pnl_Animal.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Cod Veterinario";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Horas";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Cod Cliente";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Cod Pet";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Data";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(134, 65);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(223, 20);
            this.textBox5.TabIndex = 13;
            // 
            // text_Cod_Pet
            // 
            this.text_Cod_Pet.Location = new System.Drawing.Point(134, 91);
            this.text_Cod_Pet.Name = "text_Cod_Pet";
            this.text_Cod_Pet.Size = new System.Drawing.Size(223, 20);
            this.text_Cod_Pet.TabIndex = 12;
            // 
            // text_Data
            // 
            this.text_Data.Location = new System.Drawing.Point(134, 143);
            this.text_Data.Name = "text_Data";
            this.text_Data.Size = new System.Drawing.Size(223, 20);
            this.text_Data.TabIndex = 10;
            // 
            // text_Hora
            // 
            this.text_Hora.Location = new System.Drawing.Point(134, 117);
            this.text_Hora.Name = "text_Hora";
            this.text_Hora.Size = new System.Drawing.Size(223, 20);
            this.text_Hora.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Codigo";
            // 
            // text_cod_veterinario
            // 
            this.text_cod_veterinario.Location = new System.Drawing.Point(134, 36);
            this.text_cod_veterinario.Name = "text_cod_veterinario";
            this.text_cod_veterinario.Size = new System.Drawing.Size(223, 20);
            this.text_cod_veterinario.TabIndex = 1;
            // 
            // text_cod_Consulta
            // 
            this.text_cod_Consulta.Location = new System.Drawing.Point(134, 6);
            this.text_cod_Consulta.Name = "text_cod_Consulta";
            this.text_cod_Consulta.Size = new System.Drawing.Size(100, 20);
            this.text_cod_Consulta.TabIndex = 0;
            this.text_cod_Consulta.TextChanged += new System.EventHandler(this.text_cod_Consulta_TextChanged);
            // 
            // frm_Consulta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 396);
            this.Controls.Add(this.pnl_Animal);
            this.Controls.Add(this.lbox_Consulta);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Consulta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm_Consulta";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.pnl_Animal.ResumeLayout(false);
            this.pnl_Animal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Confirma;
        private System.Windows.Forms.Button btn_Alterar;
        private System.Windows.Forms.Button btn_Novo;
        private System.Windows.Forms.ListBox lbox_Consulta;
        private System.Windows.Forms.Panel pnl_Animal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_cod_veterinario;
        private System.Windows.Forms.TextBox text_cod_Consulta;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox text_Cod_Pet;
        private System.Windows.Forms.TextBox text_Data;
        private System.Windows.Forms.TextBox text_Hora;
    }
}