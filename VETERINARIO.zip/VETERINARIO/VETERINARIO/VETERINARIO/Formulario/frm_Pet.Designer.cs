﻿namespace VETERINARIO
{
    partial class frm_Pet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Pet));
            this.pnl_Titulo = new System.Windows.Forms.Panel();
            this.label = new System.Windows.Forms.Label();
            this.pnl_Button = new System.Windows.Forms.Panel();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Confirmar = new System.Windows.Forms.Button();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.btn_Novo = new System.Windows.Forms.Button();
            this.lbox_Pet = new System.Windows.Forms.ListBox();
            this.pnl_Detalhe = new System.Windows.Forms.Panel();
            this.lb_desc_Cliente = new System.Windows.Forms.Label();
            this.lb_desc_Raca = new System.Windows.Forms.Label();
            this.lb_desc_Animal = new System.Windows.Forms.Label();
            this.btn_Cliente = new System.Windows.Forms.Button();
            this.btn_Raca = new System.Windows.Forms.Button();
            this.btn_Animal = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbox_cod_Cliente = new System.Windows.Forms.TextBox();
            this.tbox_gen_Pet = new System.Windows.Forms.TextBox();
            this.tbox_id_Pet = new System.Windows.Forms.TextBox();
            this.tbox_ps_Pet = new System.Windows.Forms.TextBox();
            this.tbox_nm_Pet = new System.Windows.Forms.TextBox();
            this.tbox_cod_Raca = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbox_cod_Animal = new System.Windows.Forms.TextBox();
            this.tbox_cod_Pet = new System.Windows.Forms.TextBox();
            this.pnl_Titulo.SuspendLayout();
            this.pnl_Button.SuspendLayout();
            this.pnl_Detalhe.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Titulo
            // 
            this.pnl_Titulo.BackColor = System.Drawing.Color.LightSeaGreen;
            this.pnl_Titulo.Controls.Add(this.label);
            this.pnl_Titulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Titulo.Location = new System.Drawing.Point(0, 0);
            this.pnl_Titulo.Name = "pnl_Titulo";
            this.pnl_Titulo.Size = new System.Drawing.Size(674, 70);
            this.pnl_Titulo.TabIndex = 12;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.Color.Black;
            this.label.Location = new System.Drawing.Point(41, 9);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(96, 55);
            this.label.TabIndex = 0;
            this.label.Text = "Pet";
            // 
            // pnl_Button
            // 
            this.pnl_Button.BackColor = System.Drawing.Color.Turquoise;
            this.pnl_Button.Controls.Add(this.btn_Excluir);
            this.pnl_Button.Controls.Add(this.btn_Cancelar);
            this.pnl_Button.Controls.Add(this.btn_Confirmar);
            this.pnl_Button.Controls.Add(this.btn_Alterar);
            this.pnl_Button.Controls.Add(this.btn_Novo);
            this.pnl_Button.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_Button.Location = new System.Drawing.Point(0, 390);
            this.pnl_Button.Name = "pnl_Button";
            this.pnl_Button.Size = new System.Drawing.Size(674, 71);
            this.pnl_Button.TabIndex = 6;
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.Location = new System.Drawing.Point(213, 22);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(75, 23);
            this.btn_Excluir.TabIndex = 2;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = true;
            this.btn_Excluir.Click += new System.EventHandler(this.btn_Excluir_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Location = new System.Drawing.Point(536, 22);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancelar.TabIndex = 4;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // btn_Confirmar
            // 
            this.btn_Confirmar.Location = new System.Drawing.Point(428, 22);
            this.btn_Confirmar.Name = "btn_Confirmar";
            this.btn_Confirmar.Size = new System.Drawing.Size(75, 23);
            this.btn_Confirmar.TabIndex = 3;
            this.btn_Confirmar.Text = "Confirma";
            this.btn_Confirmar.UseVisualStyleBackColor = true;
            this.btn_Confirmar.Click += new System.EventHandler(this.btn_Confirmar_Click);
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.Location = new System.Drawing.Point(116, 22);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(75, 23);
            this.btn_Alterar.TabIndex = 1;
            this.btn_Alterar.Text = "Alterar";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            this.btn_Alterar.Click += new System.EventHandler(this.btn_Alterar_Click);
            // 
            // btn_Novo
            // 
            this.btn_Novo.Location = new System.Drawing.Point(24, 22);
            this.btn_Novo.Name = "btn_Novo";
            this.btn_Novo.Size = new System.Drawing.Size(75, 23);
            this.btn_Novo.TabIndex = 0;
            this.btn_Novo.Text = "Novo";
            this.btn_Novo.UseVisualStyleBackColor = true;
            this.btn_Novo.Click += new System.EventHandler(this.btn_Novo_Click);
            // 
            // lbox_Pet
            // 
            this.lbox_Pet.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lbox_Pet.Dock = System.Windows.Forms.DockStyle.Left;
            this.lbox_Pet.FormattingEnabled = true;
            this.lbox_Pet.Location = new System.Drawing.Point(0, 70);
            this.lbox_Pet.Name = "lbox_Pet";
            this.lbox_Pet.Size = new System.Drawing.Size(191, 320);
            this.lbox_Pet.TabIndex = 0;
            this.lbox_Pet.DoubleClick += new System.EventHandler(this.lbox_Pets_DoubleClick);
            // 
            // pnl_Detalhe
            // 
            this.pnl_Detalhe.BackColor = System.Drawing.Color.PaleTurquoise;
            this.pnl_Detalhe.Controls.Add(this.lb_desc_Cliente);
            this.pnl_Detalhe.Controls.Add(this.lb_desc_Raca);
            this.pnl_Detalhe.Controls.Add(this.lb_desc_Animal);
            this.pnl_Detalhe.Controls.Add(this.btn_Cliente);
            this.pnl_Detalhe.Controls.Add(this.btn_Raca);
            this.pnl_Detalhe.Controls.Add(this.btn_Animal);
            this.pnl_Detalhe.Controls.Add(this.label3);
            this.pnl_Detalhe.Controls.Add(this.label10);
            this.pnl_Detalhe.Controls.Add(this.label9);
            this.pnl_Detalhe.Controls.Add(this.label8);
            this.pnl_Detalhe.Controls.Add(this.label7);
            this.pnl_Detalhe.Controls.Add(this.label6);
            this.pnl_Detalhe.Controls.Add(this.label5);
            this.pnl_Detalhe.Controls.Add(this.tbox_cod_Cliente);
            this.pnl_Detalhe.Controls.Add(this.tbox_gen_Pet);
            this.pnl_Detalhe.Controls.Add(this.tbox_id_Pet);
            this.pnl_Detalhe.Controls.Add(this.tbox_ps_Pet);
            this.pnl_Detalhe.Controls.Add(this.tbox_nm_Pet);
            this.pnl_Detalhe.Controls.Add(this.tbox_cod_Raca);
            this.pnl_Detalhe.Controls.Add(this.label2);
            this.pnl_Detalhe.Controls.Add(this.label1);
            this.pnl_Detalhe.Controls.Add(this.tbox_cod_Animal);
            this.pnl_Detalhe.Controls.Add(this.tbox_cod_Pet);
            this.pnl_Detalhe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Detalhe.Location = new System.Drawing.Point(191, 70);
            this.pnl_Detalhe.Name = "pnl_Detalhe";
            this.pnl_Detalhe.Size = new System.Drawing.Size(483, 320);
            this.pnl_Detalhe.TabIndex = 9;
            // 
            // lb_desc_Cliente
            // 
            this.lb_desc_Cliente.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lb_desc_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_desc_Cliente.Location = new System.Drawing.Point(140, 163);
            this.lb_desc_Cliente.Name = "lb_desc_Cliente";
            this.lb_desc_Cliente.Size = new System.Drawing.Size(306, 20);
            this.lb_desc_Cliente.TabIndex = 24;
            this.lb_desc_Cliente.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_desc_Raca
            // 
            this.lb_desc_Raca.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lb_desc_Raca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_desc_Raca.Location = new System.Drawing.Point(140, 122);
            this.lb_desc_Raca.Name = "lb_desc_Raca";
            this.lb_desc_Raca.Size = new System.Drawing.Size(306, 21);
            this.lb_desc_Raca.TabIndex = 20;
            this.lb_desc_Raca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_desc_Animal
            // 
            this.lb_desc_Animal.BackColor = System.Drawing.Color.MediumTurquoise;
            this.lb_desc_Animal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_desc_Animal.Location = new System.Drawing.Point(140, 85);
            this.lb_desc_Animal.Name = "lb_desc_Animal";
            this.lb_desc_Animal.Size = new System.Drawing.Size(306, 21);
            this.lb_desc_Animal.TabIndex = 18;
            this.lb_desc_Animal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_Cliente
            // 
            this.btn_Cliente.Image = ((System.Drawing.Image)(resources.GetObject("btn_Cliente.Image")));
            this.btn_Cliente.Location = new System.Drawing.Point(107, 163);
            this.btn_Cliente.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Cliente.Name = "btn_Cliente";
            this.btn_Cliente.Size = new System.Drawing.Size(26, 21);
            this.btn_Cliente.TabIndex = 23;
            this.btn_Cliente.UseVisualStyleBackColor = true;
            this.btn_Cliente.Click += new System.EventHandler(this.btn_Cliente_Click);
            // 
            // btn_Raca
            // 
            this.btn_Raca.Image = ((System.Drawing.Image)(resources.GetObject("btn_Raca.Image")));
            this.btn_Raca.Location = new System.Drawing.Point(107, 122);
            this.btn_Raca.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Raca.Name = "btn_Raca";
            this.btn_Raca.Size = new System.Drawing.Size(26, 21);
            this.btn_Raca.TabIndex = 19;
            this.btn_Raca.UseVisualStyleBackColor = true;
            this.btn_Raca.Click += new System.EventHandler(this.btn_Raca_Click);
            // 
            // btn_Animal
            // 
            this.btn_Animal.Image = ((System.Drawing.Image)(resources.GetObject("btn_Animal.Image")));
            this.btn_Animal.Location = new System.Drawing.Point(107, 84);
            this.btn_Animal.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Animal.Name = "btn_Animal";
            this.btn_Animal.Size = new System.Drawing.Size(26, 21);
            this.btn_Animal.TabIndex = 17;
            this.btn_Animal.UseVisualStyleBackColor = true;
            this.btn_Animal.Click += new System.EventHandler(this.btn_Animal_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Codigo Raça";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(42, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 13);
            this.label10.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 148);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "Codigo Cliente";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 203);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Genero";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 237);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Peso";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 270);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Idade";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(65, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Nome do Pet:";
            // 
            // tbox_cod_Cliente
            // 
            this.tbox_cod_Cliente.Location = new System.Drawing.Point(36, 164);
            this.tbox_cod_Cliente.Name = "tbox_cod_Cliente";
            this.tbox_cod_Cliente.Size = new System.Drawing.Size(66, 20);
            this.tbox_cod_Cliente.TabIndex = 22;
            this.tbox_cod_Cliente.Leave += new System.EventHandler(this.tbox_cod_Cliente_Leave);
            // 
            // tbox_gen_Pet
            // 
            this.tbox_gen_Pet.Location = new System.Drawing.Point(78, 200);
            this.tbox_gen_Pet.Name = "tbox_gen_Pet";
            this.tbox_gen_Pet.Size = new System.Drawing.Size(223, 20);
            this.tbox_gen_Pet.TabIndex = 11;
            // 
            // tbox_id_Pet
            // 
            this.tbox_id_Pet.Location = new System.Drawing.Point(78, 267);
            this.tbox_id_Pet.Name = "tbox_id_Pet";
            this.tbox_id_Pet.Size = new System.Drawing.Size(223, 20);
            this.tbox_id_Pet.TabIndex = 15;
            // 
            // tbox_ps_Pet
            // 
            this.tbox_ps_Pet.Location = new System.Drawing.Point(78, 234);
            this.tbox_ps_Pet.Name = "tbox_ps_Pet";
            this.tbox_ps_Pet.Size = new System.Drawing.Size(223, 20);
            this.tbox_ps_Pet.TabIndex = 13;
            // 
            // tbox_nm_Pet
            // 
            this.tbox_nm_Pet.Location = new System.Drawing.Point(143, 45);
            this.tbox_nm_Pet.Name = "tbox_nm_Pet";
            this.tbox_nm_Pet.Size = new System.Drawing.Size(223, 20);
            this.tbox_nm_Pet.TabIndex = 9;
            // 
            // tbox_cod_Raca
            // 
            this.tbox_cod_Raca.Location = new System.Drawing.Point(36, 124);
            this.tbox_cod_Raca.Name = "tbox_cod_Raca";
            this.tbox_cod_Raca.Size = new System.Drawing.Size(66, 20);
            this.tbox_cod_Raca.TabIndex = 7;
            this.tbox_cod_Raca.Leave += new System.EventHandler(this.tbox_cod_Raca_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Codigo Animal";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(75, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Codigo Pet:";
            // 
            // tbox_cod_Animal
            // 
            this.tbox_cod_Animal.Location = new System.Drawing.Point(36, 85);
            this.tbox_cod_Animal.Name = "tbox_cod_Animal";
            this.tbox_cod_Animal.Size = new System.Drawing.Size(66, 20);
            this.tbox_cod_Animal.TabIndex = 5;
            this.tbox_cod_Animal.Leave += new System.EventHandler(this.tbox_cod_Animal_Leave);
            // 
            // tbox_cod_Pet
            // 
            this.tbox_cod_Pet.Enabled = false;
            this.tbox_cod_Pet.Location = new System.Drawing.Point(143, 12);
            this.tbox_cod_Pet.Name = "tbox_cod_Pet";
            this.tbox_cod_Pet.Size = new System.Drawing.Size(100, 20);
            this.tbox_cod_Pet.TabIndex = 1;
            this.tbox_cod_Pet.Tag = "1";
            // 
            // frm_Pet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 461);
            this.Controls.Add(this.pnl_Detalhe);
            this.Controls.Add(this.lbox_Pet);
            this.Controls.Add(this.pnl_Button);
            this.Controls.Add(this.pnl_Titulo);
            this.Name = "frm_Pet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm_Pet";
            this.pnl_Titulo.ResumeLayout(false);
            this.pnl_Titulo.PerformLayout();
            this.pnl_Button.ResumeLayout(false);
            this.pnl_Detalhe.ResumeLayout(false);
            this.pnl_Detalhe.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Titulo;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Panel pnl_Button;
        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Confirmar;
        private System.Windows.Forms.Button btn_Alterar;
        private System.Windows.Forms.Button btn_Novo;
        private System.Windows.Forms.ListBox lbox_Pet;
        private System.Windows.Forms.Panel pnl_Detalhe;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbox_cod_Animal;
        private System.Windows.Forms.TextBox tbox_cod_Pet;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbox_cod_Cliente;
        private System.Windows.Forms.TextBox tbox_gen_Pet;
        private System.Windows.Forms.TextBox tbox_id_Pet;
        private System.Windows.Forms.TextBox tbox_ps_Pet;
        private System.Windows.Forms.TextBox tbox_nm_Pet;
        private System.Windows.Forms.TextBox tbox_cod_Raca;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_desc_Cliente;
        private System.Windows.Forms.Label lb_desc_Raca;
        private System.Windows.Forms.Label lb_desc_Animal;
        private System.Windows.Forms.Button btn_Cliente;
        private System.Windows.Forms.Button btn_Raca;
        private System.Windows.Forms.Button btn_Animal;
    }
}