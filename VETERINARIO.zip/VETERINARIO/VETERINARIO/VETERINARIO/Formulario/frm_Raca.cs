﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VETERINARIO
{
    public partial class frm_Raca : Form
    {
        FuncGeral obj_FuncGeral = new FuncGeral();
        Raca Raca_Principal = new Raca();

        public frm_Raca()
        {
            InitializeComponent();
            PopulaLista();
            obj_FuncGeral.StatusBtn(this, 0);
            obj_FuncGeral.HabilitaTela(this, false);
        }

        /**********************************************************************************
        * NOME:            PopulaLista
        * CLASSE:          Preenche o listbox com os dados dos Usuarioes cadastrados no Banco
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaLista()
        {
            BDRaca obj_BDRaca = new BDRaca();
            List<Raca> Lista = new List<Raca>();

            lbox_Raca.Items.Clear();

            Lista = obj_BDRaca.FindAllRaca();

            if (Lista != null)
            {
                for (int i = 0; i <= Lista.Count - 1; i++)
                {
                    lbox_Raca.Items.Add(Convert.ToString(Lista[i].COD_RACA) + "-" + Lista[i].DESC_RACA);
                }
            }
        }

        /**********************************************************************************
        * NOME:            PopulaTela
        * CLASSE:          Preenche o objeto Usuario no formulário
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * PARAMETRO:       Objeto Usuario 
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaTela(Raca obj_Raca)
        {
            if (obj_Raca.COD_RACA != -1)
            {
                tbox_cod_Raca.Text = Convert.ToString(obj_Raca.COD_RACA);
            }
            tbox_Desc_Raca.Text = obj_Raca.DESC_RACA;
            picBox_Foto.Image = Image.FromFile("C:/Users/JoseEgitos/Documents/Visual Studio 2015/Projects/VETERINARIO/VETERINARIO/VETERINARIO/Imagens/Raca/" + tbox_cod_Raca.Text + ".JPG");
        }

        /**********************************************************************************
        * NOME:            PopulaObjeto
        * CLASSE:          Preenche o objeto Usuario com os dados do formulário
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private Raca PopulaObjeto()
        {
            Raca obj_Raca = new Raca();

            if (lbox_Raca.Text == "")
            {
                obj_Raca.DESC_RACA = tbox_Desc_Raca.Text;
            }
            else
            {
                obj_Raca.COD_RACA = Convert.ToInt16(tbox_cod_Raca.Text);
                obj_Raca.DESC_RACA = tbox_Desc_Raca.Text;
            }

            return obj_Raca;
        }

        private void lbox_Raca_DoubleClick(object sender, EventArgs e)
        {
            BDRaca obj_BDRaca = new BDRaca();
            string slinha = lbox_Raca.Items[lbox_Raca.SelectedIndex].ToString();

            int ipos = 0;

            for (int t = 0; t <= slinha.Length; t++)
            {
                if (slinha.Substring(t, 1) == "-")
                {
                    ipos = t;
                    break;
                }
            }
            Raca_Principal.COD_RACA = Convert.ToInt16(slinha.Substring(0, ipos));

            Raca_Principal = obj_BDRaca.FindByRaca(Raca_Principal);
            PopulaTela(Raca_Principal);
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);
        }

        private void btn_Novo_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.LimpaTela(this);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_Desc_Raca.Focus();
        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_Desc_Raca.Focus();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            BDRaca obj_BDRaca = new BDRaca();

            DialogResult varResp = MessageBox.Show("Confirma a Exclusão?", "EXCLUSÃO DO Usuario", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (varResp == DialogResult.Yes)
            {
                Raca_Principal = PopulaObjeto();

                if (obj_BDRaca.Excluir(Raca_Principal))
                {
                    MessageBox.Show("Usuario excluido com sucesso.", "EXCLUSÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                obj_FuncGeral.LimpaTela(this);
                obj_FuncGeral.HabilitaTela(this, false);
                obj_FuncGeral.StatusBtn(this, 0);
                PopulaLista();
            }
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {
            BDRaca obj_BDRaca = new BDRaca();

            Raca_Principal = PopulaObjeto();

            if (Raca_Principal.COD_RACA != -1)
            {
                obj_BDRaca.Alterar(Raca_Principal);
                MessageBox.Show("Usuario alterado com sucesso.", "ALTERAÇÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                tbox_cod_Raca.Text = Convert.ToString(obj_BDRaca.Incluir(Raca_Principal));
                MessageBox.Show("Usuario incluido com sucesso.", "INCLUSÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            obj_FuncGeral.StatusBtn(this, 1);
            obj_FuncGeral.HabilitaTela(this, false);
            PopulaLista();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);
            PopulaTela(Raca_Principal);
        }

        private void btn_Fotografia_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd_Foto = new OpenFileDialog();
            ofd_Foto.Filter = "jpg files (*.jpg)|";
            //define as propriedades do controle 
            //OpenFileDialog
            ofd_Foto.Multiselect = true;
            ofd_Foto.Title = "Selecionar Fotos";
            ofd_Foto.InitialDirectory = @"C:\Users\JoseEgitos\Documents\Visual Studio 2015\Projects\VETERINARIO\VETERINARIO\VETERINARIO\Imagens\Raca\";
            //filtra para exibir somente arquivos de imagens
            ofd_Foto.Filter = "Images (*.BMP;*.JPG;*.GIF,*.PNG,*.TIFF)|*.BMP;*.JPG;*.GIF;*.PNG;*.TIFF|" + "All files (*.*)|*.*";
            ofd_Foto.CheckFileExists = true;
            ofd_Foto.CheckPathExists = true;
            ofd_Foto.FilterIndex = 2;
            ofd_Foto.RestoreDirectory = true;
            ofd_Foto.ReadOnlyChecked = true;
            ofd_Foto.ShowReadOnly = true;

            DialogResult dr = ofd_Foto.ShowDialog();

            if (dr == System.Windows.Forms.DialogResult.OK)
            {

                picBox_Foto.Image = Image.FromFile(ofd_Foto.FileName);
                picBox_Foto.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            PopulaLista();
        }
    }
}
