﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;

namespace VETERINARIO
{
    public partial class frm_Cliente : Form
    {
        FuncGeral obj_FuncGeral = new FuncGeral();
        Cliente Cliente_Principal = new Cliente();

        public frm_Cliente()
        {
            InitializeComponent();
            PopulaLista();
            obj_FuncGeral.StatusBtn(this, 0);
            obj_FuncGeral.HabilitaTela(this, false);
        }

        /**********************************************************************************
        * NOME:            PopulaLista
        * CLASSE:          Preenche o listbox com os dados dos Usuarioes cadastrados no Banco
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaLista()
        {
            BDCliente obj_BDCliente = new BDCliente();
            List<Cliente> Lista = new List<Cliente>();

            lbox_Cliente.Items.Clear();

            Lista = obj_BDCliente.FindAllCliente();

            if (Lista != null)
            {
                for (int i = 0; i <= Lista.Count - 1; i++)
                {
                    lbox_Cliente.Items.Add(Convert.ToString(Lista[i].COD_CLIENTE) + "-" + Lista[i].NM_CLIENTE);
                }
            }
        }

        /**********************************************************************************
       * NOME:            PopulaTela
       * CLASSE:          Preenche o objeto Usuario no formulário
       * DT CRIAÇÃO:      28/05/2019
       * DT ALTERAÇÃO:    -
       * PARAMETRO:       Objeto Usuario 
       * ESCRITA POR:     Monstro (mFacine)
       * OBSERVAÇÕES:     
       * ********************************************************************************/
        private void PopulaTela(Cliente obj_Cliente)
        {
            if (obj_Cliente.COD_CLIENTE != -1)
            {
                tbox_cod_Cliente.Text = Convert.ToString(obj_Cliente.COD_CLIENTE);
            }
            tbox_nm_Cliente.Text = obj_Cliente.NM_CLIENTE;
            tbox_cpf_Cliente.Text = obj_Cliente.CPF_CLIENTE;
            tbox_rg_Cliente.Text = obj_Cliente.RG_CLIENTE;
            tbox_end_Cliente.Text = obj_Cliente.END_CLIENTE;
            tbox_fn_Cliente.Text = obj_Cliente.FN_CLIENTE;
            tbox_mail_Cliente.Text = obj_Cliente.MAIL_CLIENTE;
        }

        /**********************************************************************************
        * NOME:            PopulaObjeto
        * CLASSE:          Preenche o objeto Usuario com os dados do formulário
        * DT CRIAÇÃO:      28/05/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private Cliente PopulaObjeto()
        {
            Cliente obj_Cliente = new Cliente();

            if (tbox_cod_Cliente.Text == "")
            {
                obj_Cliente.NM_CLIENTE = tbox_nm_Cliente.Text;
                obj_Cliente.CPF_CLIENTE = tbox_cpf_Cliente.Text;
                obj_Cliente.RG_CLIENTE = tbox_rg_Cliente.Text;
                obj_Cliente.END_CLIENTE = tbox_end_Cliente.Text;
                obj_Cliente.FN_CLIENTE = tbox_fn_Cliente.Text;
                obj_Cliente.MAIL_CLIENTE = tbox_mail_Cliente.Text;
            }
            else
            {
                obj_Cliente.COD_CLIENTE = Convert.ToInt16(tbox_cod_Cliente.Text);
                obj_Cliente.NM_CLIENTE = tbox_nm_Cliente.Text;
                obj_Cliente.CPF_CLIENTE = tbox_cpf_Cliente.Text;
                obj_Cliente.RG_CLIENTE = tbox_rg_Cliente.Text;
                obj_Cliente.END_CLIENTE = tbox_end_Cliente.Text;
                obj_Cliente.FN_CLIENTE = tbox_fn_Cliente.Text;
                obj_Cliente.MAIL_CLIENTE = tbox_mail_Cliente.Text;
            }

            return obj_Cliente;
        }

        private void lbox_Cliente_DoubleClick(object sender, EventArgs e)
        {
            BDCliente obj_BDCliente = new BDCliente();
            string slinha = lbox_Cliente.Items[lbox_Cliente.SelectedIndex].ToString();

            int ipos = 0;

            for (int t = 0; t <= slinha.Length; t++)
            {
                if (slinha.Substring(t, 1) == "-")
                {
                    ipos = t;
                    break;
                }
            }
            Cliente_Principal.COD_CLIENTE = Convert.ToInt16(slinha.Substring(0, ipos));

            Cliente_Principal = obj_BDCliente.FindByCliente(Cliente_Principal);
            PopulaTela(Cliente_Principal);
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);
        }

        private void btn_Novo_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.LimpaTela(this);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_nm_Cliente.Focus();
        }

        //btn_Alterar
        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_nm_Cliente.Focus();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            BDCliente obj_BDCliente = new BDCliente();

            DialogResult varResp = MessageBox.Show("Confirma a Exclusão?", "EXCLUSÃO DO Usuario", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (varResp == DialogResult.Yes)
            {
                Cliente_Principal = PopulaObjeto();

                if (obj_BDCliente.Excluir(Cliente_Principal))
                {
                    MessageBox.Show("Usuario excluido com sucesso.", "EXCLUSÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                obj_FuncGeral.LimpaTela(this);
                obj_FuncGeral.HabilitaTela(this, false);
                obj_FuncGeral.StatusBtn(this, 0);
                PopulaLista();
            }
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);
            PopulaTela(Cliente_Principal);
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {
            BDCliente obj_BDCliente = new BDCliente();

            Cliente_Principal = PopulaObjeto();

            if (Cliente_Principal.COD_CLIENTE != -1)
            {
                obj_BDCliente.Alterar(Cliente_Principal);
                MessageBox.Show("Usuario alterado com sucesso.", "ALTERAÇÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                tbox_cod_Cliente.Text = Convert.ToString(obj_BDCliente.Incluir(Cliente_Principal));
                MessageBox.Show("Usuario incluido com sucesso.", "INCLUSÃO DO Usuario", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            obj_FuncGeral.StatusBtn(this, 1);
            obj_FuncGeral.HabilitaTela(this, false);
            PopulaLista();
        }
    }
}



