﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VETERINARIO
{
    public partial class frm_Pet : Form
    {

        FuncGeral obj_FuncGeral = new FuncGeral();
        Pet Pet_Principal = new Pet();

        public frm_Pet()
        {
            InitializeComponent();
            PopulaLista();
            obj_FuncGeral.StatusBtn(this, 0);
            obj_FuncGeral.HabilitaTela(this, false);

        }

        /**********************************************************************************
        * NOME:            PopulaLista
        * CLASSE:          Preenche o listbox com os dados dos Livros cadastrados no Banco
        * DT CRIAÇÃO:      04/06/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaLista()
        {

            BDPet obj_BDLivro = new BDPet();
            List<Pet> Lista = new List<Pet>();

            lbox_Pet.Items.Clear();

            Lista = obj_BDLivro.FindAllPet();

            if (Lista != null)
            {
                for (int i = 0; i <= Lista.Count - 1; i++)
                {
                    lbox_Pet.Items.Add(Convert.ToString(Lista[i].COD_PET) + "-" + Lista[i].NM_PET);
                }
            }
        }

        /**********************************************************************************
        * NOME:            PopulaTela
        * CLASSE:          Preenche o objeto Livro no formulário
        * DT CRIAÇÃO:      04/06/2019
        * DT ALTERAÇÃO:    -
        * PARAMETRO:       Objeto Livro 
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private void PopulaTela(Pet obj_Pet)
        {
            BDAnimal obj_BDAnimal = new BDAnimal();
            Animal obj_Animal = new Animal();

            BDRaca obj_BDRaca = new BDRaca();
            Raca obj_Raca = new Raca();

            BDCliente obj_BDCliente = new BDCliente();
            Cliente obj_Cliente = new Cliente();

            if (obj_Pet.COD_PET != -1)
            {
                tbox_cod_Pet.Text = Convert.ToString(obj_Pet.COD_PET);
            }

            if (obj_Pet.COD_ANIMAL!=-1)
            {
                tbox_cod_Animal.Text = Convert.ToString(obj_Pet.COD_ANIMAL);
                obj_Animal.COD_ANIMAL = obj_Pet.COD_ANIMAL;
                lb_desc_Animal.Text = obj_BDAnimal.FindByAnimal(obj_Animal).DESC_ANIMAL;
            }

            if (obj_Pet.COD_RACA != -1)
            {
                tbox_cod_Raca.Text = Convert.ToString(obj_Pet.COD_RACA);
                obj_Raca.COD_RACA = obj_Pet.COD_RACA;
                lb_desc_Raca.Text = obj_BDRaca.FindByRaca(obj_Raca).DESC_RACA;
            }

            if (obj_Pet.COD_CLIENTE != -1)
            {
                tbox_cod_Cliente.Text = Convert.ToString(obj_Pet.COD_CLIENTE);
                obj_Cliente.COD_CLIENTE = obj_Pet.COD_CLIENTE;
                lb_desc_Cliente.Text = obj_BDCliente.FindByCliente(obj_Cliente).NM_CLIENTE;
            }

            tbox_nm_Pet.Text = obj_Pet.NM_PET;
            tbox_gen_Pet.Text = obj_Pet.GEN_PET;

            if (obj_Pet.PS_PET != -1)
            {
                tbox_ps_Pet.Text = Convert.ToString(obj_Pet.PS_PET);
            }

            if (obj_Pet.ID_PET != -1)
            {
                tbox_id_Pet.Text = Convert.ToString(obj_Pet.ID_PET);
            }
        }

        /**********************************************************************************
        * NOME:            PopulaObjeto
        * CLASSE:          Preenche o objeto Livro com os dados do formulário
        * DT CRIAÇÃO:      04/06/2019
        * DT ALTERAÇÃO:    -
        * ESCRITA POR:     Monstro (mFacine)
        * OBSERVAÇÕES:     
        * ********************************************************************************/
        private Pet PopulaObjeto()
        {
            Pet obj_Pet = new Pet();

            if (tbox_cod_Pet.Text == "")
            {
                obj_Pet.COD_ANIMAL = Convert.ToInt16(tbox_cod_Animal.Text);
                obj_Pet.COD_RACA = Convert.ToInt16(tbox_cod_Raca.Text);
                obj_Pet.COD_CLIENTE = Convert.ToInt16(tbox_cod_Cliente.Text);
                obj_Pet.NM_PET = tbox_nm_Pet.Text;
                obj_Pet.GEN_PET = tbox_gen_Pet.Text;
                obj_Pet.PS_PET = Convert.ToInt16(tbox_ps_Pet.Text);
                obj_Pet.ID_PET = Convert.ToInt16(tbox_id_Pet.Text);
            }
            else
            {
                obj_Pet.COD_PET = Convert.ToInt16(tbox_cod_Pet.Text);
                obj_Pet.COD_ANIMAL = Convert.ToInt16(tbox_cod_Animal.Text);
                obj_Pet.COD_RACA = Convert.ToInt16(tbox_cod_Raca.Text);
                obj_Pet.COD_CLIENTE = Convert.ToInt16(tbox_cod_Cliente.Text);
                obj_Pet.NM_PET = tbox_nm_Pet.Text;
                obj_Pet.GEN_PET = tbox_gen_Pet.Text;
                obj_Pet.PS_PET = Convert.ToInt16(tbox_ps_Pet.Text);
                obj_Pet.ID_PET = Convert.ToInt16(tbox_id_Pet.Text);
            }

            return obj_Pet;
        }

        private void lbox_Pets_DoubleClick(object sender, EventArgs e)
        {
            BDPet obj_BDPet = new BDPet();
            string slinha = lbox_Pet.Items[lbox_Pet.SelectedIndex].ToString();

            int ipos = 0;

            for (int t = 0; t <= slinha.Length; t++)
            {
                if (slinha.Substring(t, 1) == "-")
                {
                    ipos = t;
                    break;
                }
            }
            Pet_Principal.COD_PET = Convert.ToInt16(slinha.Substring(0, ipos));

            Pet_Principal = obj_BDPet.FindByPet(Pet_Principal);
            PopulaTela(Pet_Principal);
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);


        }

        private void btn_Novo_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.LimpaTela(this);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_nm_Pet.Focus();
        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, true);
            obj_FuncGeral.StatusBtn(this, 2);
            tbox_nm_Pet.Focus();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            BDPet obj_BDPet = new BDPet();

            DialogResult varResp = MessageBox.Show("Confirma a Exclusão?", "EXCLUSÃO DO Livro", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (varResp == DialogResult.Yes)
            {
                Pet_Principal = PopulaObjeto();

                if (obj_BDPet.Excluir(Pet_Principal))
                {
                    MessageBox.Show("Livro excluido com sucesso.", "EXCLUSÃO DO Livro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                obj_FuncGeral.LimpaTela(this);
                obj_FuncGeral.HabilitaTela(this, false);
                obj_FuncGeral.StatusBtn(this, 0);
                PopulaLista();
            }
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {
            BDPet obj_BDPet = new BDPet();

            Pet_Principal = PopulaObjeto();

            if (Pet_Principal.COD_PET != -1)
            {
                obj_BDPet.Alterar(Pet_Principal);
                MessageBox.Show("Livro alterado com sucesso.", "ALTERAÇÃO DO Livro", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                tbox_cod_Pet.Text = Convert.ToString(obj_BDPet.Incluir(Pet_Principal));
                MessageBox.Show("Livro incluido com sucesso.", "INCLUSÃO DO Livro", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            obj_FuncGeral.StatusBtn(this, 1);
            obj_FuncGeral.HabilitaTela(this, false);
            PopulaLista();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            obj_FuncGeral.HabilitaTela(this, false);
            obj_FuncGeral.StatusBtn(this, 1);
            PopulaTela(Pet_Principal);
        }

        private void btn_Animal_Click(object sender, EventArgs e)
        {
            frm_Animal obj_frm_Animal = new frm_Animal();
            obj_frm_Animal.ShowDialog();
        }

        private void btn_Raca_Click(object sender, EventArgs e)
        {
            frm_Raca obj_frm_Raca = new frm_Raca();
            obj_frm_Raca.ShowDialog();
        }

        private void btn_Cliente_Click(object sender, EventArgs e)
        {
            frm_Cliente obj_frm_Cliente = new frm_Cliente();
            obj_frm_Cliente.ShowDialog();
        }

        private void tbox_cod_Animal_Leave(object sender, EventArgs e)
        {
            if (tbox_cod_Animal.Text != "")
            {
                BDAnimal obj_BDAnimal = new BDAnimal();
                Animal obj_Animal = new Animal();
                obj_Animal.COD_ANIMAL = Convert.ToInt16(tbox_cod_Animal.Text);
                lb_desc_Animal.Text = obj_BDAnimal.FindByAnimal(obj_Animal).DESC_ANIMAL;
            }
        }

        private void tbox_cod_Raca_Leave(object sender, EventArgs e)
        {
            if (tbox_cod_Raca.Text != "")
            {
                BDRaca obj_BDRaca = new BDRaca();
                Raca obj_Raca = new Raca();
                obj_Raca.COD_RACA = Convert.ToInt16(tbox_cod_Raca.Text);
                lb_desc_Raca.Text = obj_BDRaca.FindByRaca(obj_Raca).DESC_RACA;
            }
        }

        private void tbox_cod_Cliente_Leave(object sender, EventArgs e)
        {
            if (tbox_cod_Cliente.Text != "")
            {
                BDCliente obj_BDCliente = new BDCliente();
                Cliente obj_Cliente = new Cliente();
                obj_Cliente.COD_CLIENTE = Convert.ToInt16(tbox_cod_Cliente.Text);
                lb_desc_Cliente.Text = obj_BDCliente.FindByCliente(obj_Cliente).NM_CLIENTE;
            }
        }
    }
}
